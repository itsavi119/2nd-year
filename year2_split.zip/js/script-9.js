    // ══════════════════════════════════════════════════════════════
    // PREMIUM MICRO-INTERACTIONS — press-scale, tap ripple, haptics
    // Applies to the app's primary tap targets: the bottom nav, every
    // subject page's back button + Overview/Chapters tab bar, and the
    // plain .back-btn used elsewhere. Uses event delegation (one pair
    // of listeners on document) so it works for every matching button
    // already in the page without touching their individual markup.
    // Press-scale is set as an inline style rather than via a CSS
    // class: several of these buttons already carry their own scoped
    // `transition` shorthand (e.g. #lnPharmacognosy .pcog-tab), which
    // would win the cascade over a same-property class rule and quietly
    // block the animation. An inline style always wins instead, with no
    // risk of side effects since it only ever sets transform/transition
    // and clears them back to '' (i.e. "defer to the stylesheet") on
    // release — it never overwrites any other inline style a button
    // might already have.
    // ══════════════════════════════════════════════════════════════
    (function microInteractionsInit() {
        // Some mobile WebViews only start honoring the :active pseudo-
        // class on tap once *something* is listening for touch events —
        // without this, presses can silently render with no pressed
        // state at all. Cheap, passive, and otherwise a no-op.
        document.addEventListener('touchstart', function () {}, { passive: true });

        var MI_SELECTOR = '.bottom-nav-item, .back-btn, .sy-back,' +
            '.pcog-back, .yr2-back, .patho-back, .pmic-back, .pharm1-back, .cp-back, .ptx-back,' +
            '.pcog-tab, .yr2-tab, .patho-tab, .pmic-tab, .pharm1-tab, .cp-tab, .ptx-tab';

        var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
        var PRESS_TRANSITION   = 'transform 0.18s cubic-bezier(0.33,1,0.68,1)';
        var RELEASE_TRANSITION = 'transform 0.28s cubic-bezier(0.33,1,0.68,1)';
        var activeEl = null;

        function press(el) {
            if (el._miClearT) { clearTimeout(el._miClearT); el._miClearT = null; }
            el.style.transition = reduceMotion ? 'none' : PRESS_TRANSITION;
            el.style.transform = 'scale(0.975)';
        }
        function release(el) {
            if (reduceMotion) {
                el.style.transition = 'none';
                el.style.transform = '';
                el._miClearT = setTimeout(function () {
                    el.style.transition = '';
                    el._miClearT = null;
                }, 0);
                return;
            }
            el.style.transition = RELEASE_TRANSITION;
            el.style.transform = '';
            // Once the release animation finishes, drop the inline
            // transition entirely so this button's own stylesheet
            // transition (e.g. .back-btn's hover fade) governs again
            // instead of being permanently shadowed by this override.
            el._miClearT = setTimeout(function () {
                el.style.transition = '';
                el._miClearT = null;
            }, 300);
        }
        function spawnRipple(el, x, y) {
            if (reduceMotion) return;
            var ripple = document.createElement('span');
            ripple.className = 'mi-ripple';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.style.color = getComputedStyle(el).color;
            document.body.appendChild(ripple);
            var cleanup = function () { if (ripple.parentNode) ripple.parentNode.removeChild(ripple); };
            ripple.addEventListener('animationend', cleanup);
            setTimeout(cleanup, 400); // safety net if animationend never fires
        }
        function fireHaptic(pointerType) {
            if (pointerType !== 'touch') return; // skip mouse/pen — feels odd outside real touch
            if (!('vibrate' in navigator)) return;
            try { navigator.vibrate(4); } catch (e) { /* ignore */ }
        }

        document.addEventListener('pointerdown', function (e) {
            var el = e.target.closest ? e.target.closest(MI_SELECTOR) : null;
            if (!el) return;
            activeEl = el;
            press(el);
            spawnRipple(el, e.clientX, e.clientY);
            fireHaptic(e.pointerType);
        }, { passive: true });

        function endPress() {
            if (!activeEl) return;
            release(activeEl);
            activeEl = null;
        }
        document.addEventListener('pointerup', endPress, { passive: true });
        document.addEventListener('pointercancel', endPress, { passive: true });
    })();
    
