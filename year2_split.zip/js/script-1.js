        // Many Android browsers keep honoring a page's own "width=device-width"
        // viewport even when the user turns on "Desktop site", so the page
        // never actually receives extra width and responsive (min-width)
        // CSS rules never fire. Detect that situation — a touch-capable
        // device whose user-agent no longer looks like a mobile UA — and
        // widen the viewport ourselves so the layout genuinely switches to
        // its desktop/tablet sizing, matching real desktop behavior.
        (function () {
            try {
                var isTouch = (navigator.maxTouchPoints || 0) > 0 || 'ontouchstart' in window;
                var uaLooksMobile = /Mobi|Android(?!.*Chrome\/[0-9]+\.0\.0\.0 Safari)/i.test(navigator.userAgent) && /Mobile/i.test(navigator.userAgent);
                if (isTouch && !uaLooksMobile) {
                    var vp = document.getElementById('viewportMeta');
                    if (vp) vp.setAttribute('content', 'width=1024, initial-scale=1');
                }
            } catch (e) {}
        })();
    
