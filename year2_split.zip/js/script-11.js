        // ═══════════════════════════════════════════════════════════════
        // Pharm D Notes — standalone page
        // Split out of index.html. Reuses the exact same LN_PDF_MAP,
        // PDF.js viewer, page markup and ids, so paths and behavior
        // are unchanged from the embedded version.
        // ═══════════════════════════════════════════════════════════════

        // ── Settings (shared localStorage key with PharmD Core so dark
        //    mode / sound preference stay consistent across both pages) ──
        let settings = {
            darkMode: false,
            autoSave: true,
            soundNotifications: false,
            animationEffects: true
        };

        (function loadPharmdSettings() {
            try {
                const saved = localStorage.getItem('medcalc_settings');
                if (saved) settings = Object.assign(settings, JSON.parse(saved));
                if (settings.darkMode) document.body.setAttribute('data-theme', 'dark');
                if (!settings.animationEffects) {
                    const style = document.createElement('style');
                    style.id = 'disable-animations';
                    style.textContent = `
                        *, *::before, *::after {
                            animation-duration: 0.01ms !important;
                            animation-iteration-count: 1 !important;
                            transition-duration: 0.01ms !important;
                            scroll-behavior: auto !important;
                        }
                    `;
                    document.head.appendChild(style);
                }
            } catch (e) { console.warn('Could not load settings:', e); }
        })();

        // ── Reusable sound player (identical to PharmD Core's) ───────────
        function playSound(type) {
            if (!settings.soundNotifications) return;
            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const osc  = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.connect(gain);
                gain.connect(ctx.destination);
                if (type === 'select') {
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(600, ctx.currentTime);
                    osc.frequency.setValueAtTime(900, ctx.currentTime + 0.06);
                    gain.gain.setValueAtTime(0.12, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
                    osc.start(ctx.currentTime);
                    osc.stop(ctx.currentTime + 0.18);
                } else if (type === 'success') {
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(880, ctx.currentTime);
                    osc.frequency.setValueAtTime(1100, ctx.currentTime + 0.1);
                    gain.gain.setValueAtTime(0.18, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
                    osc.start(ctx.currentTime);
                    osc.stop(ctx.currentTime + 0.35);
                } else if (type === 'error') {
                    osc.type = 'sawtooth';
                    osc.frequency.setValueAtTime(220, ctx.currentTime);
                    osc.frequency.setValueAtTime(180, ctx.currentTime + 0.1);
                    gain.gain.setValueAtTime(0.15, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
                    osc.start(ctx.currentTime);
                    osc.stop(ctx.currentTime + 0.4);
                } else {
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(660, ctx.currentTime);
                    gain.gain.setValueAtTime(0.12, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);
                    osc.start(ctx.currentTime);
                    osc.stop(ctx.currentTime + 0.22);
                }
            } catch (e) {}
        }

        // ── Minimal AppState (same shape/behavior as PharmD Core's) ──────
        class AppState {
            constructor() {
                this.currentPage = 'lecturerNotes';
                this.isLoading = false;
            }
            setLoading(loading) {
                this.isLoading = loading;
                const spinner = document.getElementById('loadingSpinner');
                if (spinner) spinner.style.display = loading ? 'block' : 'none';
            }
            showNotification(message, type = 'success', duration = 2500) {
                playSound(type);
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:0.75rem;">
                    <span style="font-size:0.83rem;">${message}</span>
                    <button onclick="this.closest('.toast').classList.add('hide');setTimeout(()=>this.closest('.toast')?.remove(),250)"
                        style="background:none;border:none;color:inherit;cursor:pointer;font-size:1rem;opacity:0.6;flex-shrink:0;">×</button>
                </div>`;
                const container = document.getElementById('toastContainer');
                if (!container) return;
                container.appendChild(toast);
                requestAnimationFrame(() =>requestAnimationFrame(() =>toast.classList.add('show')));
                setTimeout(() => {
                    toast.classList.add('hide');
                    setTimeout(() =>toast.remove(), 280);
                }, duration);
            }
        }
        const appState = new AppState();

        // ═══════════════════════════════════════════════════════════════
        // Nav — same stack-based SPA router pattern as index.html, scoped
        // to the Pharm D Notes pages. Base page is 'lecturerNotes'
        // (equivalent of index.html's 'home'). When back is pressed at
        // the base page, we leave this document and return to
        // index.html — the equivalent of Nav.back() falling through to
        // 'home' in the original app.
        // ═══════════════════════════════════════════════════════════════
        // ═══════════════════════════════════════════════════════════════
        // CROSS-FILE NAVIGATION — Pharm D Notes is split into six
        // year-wise files (year1.html … year6.html) that share this same
        // script. LN_FILE_MAP tells Nav which file a given page id lives
        // in, so that clicking a link to a page that isn't in *this*
        // file (e.g. Year 2 content from inside year1.html) transparently
        // navigates the browser to the right file, landing straight on
        // that page via the URL hash. Pages that live in every file
        // (lecturerNotes, lnSaved) are always found locally and never hit
        // this fallback.
        // ═══════════════════════════════════════════════════════════════
        var LN_CURRENT_FILE = "year2.html";
        var LN_FILE_MAP = {"lnYear1":"year1.html","lnHAP":"year1.html","lnHAP-U1":"year1.html","lnHAP-U1-T1":"year1.html","lnHAP-U2":"year1.html","lnHAP-U2-T1":"year1.html","lnHAP-U3":"year1.html","lnHAP-U3-T1":"year1.html","lnHAP-U4":"year1.html","lnHAP-U4-T1":"year1.html","lnHAP-U4-T2":"year1.html","lnHAP-U5":"year1.html","lnHAP-U5-T1":"year1.html","lnHAP-U5-T2":"year1.html","lnHAP-U5-T3":"year1.html","lnHAP-U5-T4":"year1.html","lnHAP-U5-T5":"year1.html","lnHAP-U6":"year1.html","lnHAP-U6-T1":"year1.html","lnHAP-U6-T2":"year1.html","lnHAP-U6-T3":"year1.html","lnHAP-U7":"year1.html","lnHAP-U7-T1":"year1.html","lnHAP-U7-T2":"year1.html","lnHAP-U7-T3":"year1.html","lnHAP-U7-T4":"year1.html","lnHAP-U7-T5":"year1.html","lnHAP-U7-T6":"year1.html","lnHAP-U8":"year1.html","lnHAP-U8-T1":"year1.html","lnHAP-U8-T2":"year1.html","lnHAP-U8-T3":"year1.html","lnHAP-U8-T4":"year1.html","lnHAP-U8-T5":"year1.html","lnHAP-U9":"year1.html","lnHAP-U9-T1":"year1.html","lnHAP-U9-T2":"year1.html","lnHAP-U9-T3":"year1.html","lnHAP-U9-T4":"year1.html","lnHAP-U10":"year1.html","lnHAP-U10-T1":"year1.html","lnHAP-U10-T2":"year1.html","lnHAP-U10-T3":"year1.html","lnHAP-U10-T4":"year1.html","lnHAP-U10-T5":"year1.html","lnHAP-U10-T6":"year1.html","lnHAP-U10-T7":"year1.html","lnHAP-U10-T8":"year1.html","lnHAP-U11":"year1.html","lnHAP-U11-T1":"year1.html","lnHAP-U11-T2":"year1.html","lnHAP-U11-T3":"year1.html","lnHAP-U11-T4":"year1.html","lnHAP-U12":"year1.html","lnHAP-U12-T1":"year1.html","lnHAP-U12-T2":"year1.html","lnHAP-U12-T3":"year1.html","lnHAP-U12-T4":"year1.html","lnHAP-U13":"year1.html","lnHAP-U13-T1":"year1.html","lnHAP-U13-T2":"year1.html","lnHAP-U13-T3":"year1.html","lnHAP-U13-T4":"year1.html","lnHAP-U13-T5":"year1.html","lnHAP-U13-T6":"year1.html","lnHAP-U14":"year1.html","lnHAP-U14-T1":"year1.html","lnHAP-U14-T2":"year1.html","lnHAP-U14-T3":"year1.html","lnHAP-U14-T4":"year1.html","lnHAP-U15":"year1.html","lnHAP-U15-T1":"year1.html","lnHAP-U15-T2":"year1.html","lnHAP-U15-T3":"year1.html","lnHAP-U16":"year1.html","lnHAP-U16-T1":"year1.html","lnHAP-U16-T2":"year1.html","lnHAP-U16-T3":"year1.html","lnPharmaceutics":"year1.html","lnPharmaceutics-U1":"year1.html","lnPharmaceutics-U1-T1":"year1.html","lnPharmaceutics-U1-T2":"year1.html","lnPharmaceutics-U1-T3":"year1.html","lnPharmaceutics-U2":"year1.html","lnPharmaceutics-U2-T1":"year1.html","lnPharmaceutics-U3":"year1.html","lnPharmaceutics-U3-T1":"year1.html","lnPharmaceutics-U3-T2":"year1.html","lnPharmaceutics-U4":"year1.html","lnPharmaceutics-U4-T1":"year1.html","lnPharmaceutics-U4-T2":"year1.html","lnPharmaceutics-U4-T3":"year1.html","lnPharmaceutics-U4-T4":"year1.html","lnPharmaceutics-U4-T5":"year1.html","lnPharmaceutics-U5":"year1.html","lnPharmaceutics-U5-T1":"year1.html","lnPharmaceutics-U5-T2":"year1.html","lnPharmaceutics-U5-T3":"year1.html","lnPharmaceutics-U5-T4":"year1.html","lnPharmaceutics-U5-T5":"year1.html","lnPharmaceutics-U5-T6":"year1.html","lnPharmaceutics-U5-T7":"year1.html","lnPharmaceutics-U6":"year1.html","lnPharmaceutics-U6-T1":"year1.html","lnPharmaceutics-U6-T2":"year1.html","lnPharmaceutics-U6-T3":"year1.html","lnPharmaceutics-U6-T4":"year1.html","lnPharmaceutics-U6-T5":"year1.html","lnPharmaceutics-U6-T6":"year1.html","lnPharmaceutics-U6-T7":"year1.html","lnPharmaceutics-U6-T8":"year1.html","lnPharmaceutics-U7":"year1.html","lnPharmaceutics-U7-T1":"year1.html","lnPharmaceutics-U7-T2":"year1.html","lnPharmaceutics-U7-T3":"year1.html","lnPharmaceutics-U7-T4":"year1.html","lnPharmaceutics-U7-T5":"year1.html","lnPharmaceutics-U8":"year1.html","lnPharmaceutics-U8-T1":"year1.html","lnPharmaceutics-U8-T2":"year1.html","lnPharmaceutics-U8-T3":"year1.html","lnPharmaceutics-U8-T4":"year1.html","lnPharmaceutics-U8-T5":"year1.html","lnPharmaceutics-U9":"year1.html","lnPharmaceutics-U9-T1":"year1.html","lnPharmaceutics-U9-T2":"year1.html","lnPharmaceutics-U9-T3":"year1.html","lnPharmaceutics-U9-T4":"year1.html","lnPharmaceutics-U10":"year1.html","lnPharmaceutics-U10-T1":"year1.html","lnPharmaceutics-U11":"year1.html","lnPharmaceutics-U11-T1":"year1.html","lnPharmaceutics-U11-T2":"year1.html","lnPharmaceutics-U11-T3":"year1.html","lnPharmaceutics-U11-T4":"year1.html","lnPharmaceutics-U11-T5":"year1.html","lnPharmaceutics-U12":"year1.html","lnPharmaceutics-U12-T1":"year1.html","lnPharmaceutics-U12-T2":"year1.html","lnPharmaceutics-U12-T3":"year1.html","lnMedBiochem":"year1.html","lnMedBiochem-U1":"year1.html","lnMedBiochem-U1-T1":"year1.html","lnMedBiochem-U1-T2":"year1.html","lnMedBiochem-U1-T3":"year1.html","lnMedBiochem-U1-T4":"year1.html","lnMedBiochem-U2":"year1.html","lnMedBiochem-U2-T1":"year1.html","lnMedBiochem-U2-T2":"year1.html","lnMedBiochem-U2-T3":"year1.html","lnMedBiochem-U2-T4":"year1.html","lnMedBiochem-U2-T5":"year1.html","lnMedBiochem-U2-T6":"year1.html","lnMedBiochem-U2-T7":"year1.html","lnMedBiochem-U2-T8":"year1.html","lnMedBiochem-U2-T9":"year1.html","lnMedBiochem-U3":"year1.html","lnMedBiochem-U3-T1":"year1.html","lnMedBiochem-U3-T2":"year1.html","lnMedBiochem-U3-T3":"year1.html","lnMedBiochem-U3-T4":"year1.html","lnMedBiochem-U3-T5":"year1.html","lnMedBiochem-U3-T6":"year1.html","lnMedBiochem-U3-T7":"year1.html","lnMedBiochem-U3-T8":"year1.html","lnMedBiochem-U3-T9":"year1.html","lnMedBiochem-U4":"year1.html","lnMedBiochem-U4-T1":"year1.html","lnMedBiochem-U4-T2":"year1.html","lnMedBiochem-U4-T3":"year1.html","lnMedBiochem-U4-T4":"year1.html","lnMedBiochem-U4-T5":"year1.html","lnMedBiochem-U4-T6":"year1.html","lnMedBiochem-U5":"year1.html","lnMedBiochem-U5-T1":"year1.html","lnMedBiochem-U5-T2":"year1.html","lnMedBiochem-U5-T3":"year1.html","lnMedBiochem-U5-T4":"year1.html","lnMedBiochem-U5-T5":"year1.html","lnMedBiochem-U6":"year1.html","lnMedBiochem-U6-T1":"year1.html","lnMedBiochem-U6-T2":"year1.html","lnMedBiochem-U6-T3":"year1.html","lnMedBiochem-U6-T4":"year1.html","lnMedBiochem-U6-T5":"year1.html","lnMedBiochem-U6-T6":"year1.html","lnMedBiochem-U6-T7":"year1.html","lnMedBiochem-U7":"year1.html","lnMedBiochem-U7-T1":"year1.html","lnMedBiochem-U7-T2":"year1.html","lnMedBiochem-U7-T3":"year1.html","lnMedBiochem-U7-T4":"year1.html","lnMedBiochem-U7-T5":"year1.html","lnMedBiochem-U7-T6":"year1.html","lnMedBiochem-U8":"year1.html","lnMedBiochem-U8-T1":"year1.html","lnMedBiochem-U8-T2":"year1.html","lnMedBiochem-U9":"year1.html","lnMedBiochem-U9-T1":"year1.html","lnMedBiochem-U9-T2":"year1.html","lnMedBiochem-U9-T3":"year1.html","lnMedBiochem-U9-T4":"year1.html","lnMedBiochem-U9-T5":"year1.html","lnMedBiochem-U9-T6":"year1.html","lnMedBiochem-U9-T7":"year1.html","lnMedBiochem-U10":"year1.html","lnMedBiochem-U10-T1":"year1.html","lnMedBiochem-U10-T2":"year1.html","lnMedBiochem-U10-T3":"year1.html","lnMedBiochem-U10-T4":"year1.html","lnMedBiochem-U10-T5":"year1.html","lnMedBiochem-U10-T6":"year1.html","lnMedBiochem-U10-T7":"year1.html","lnMedBiochem-U10-T8":"year1.html","lnMedBiochem-U11":"year1.html","lnMedBiochem-U11-T1":"year1.html","lnMedBiochem-U11-T2":"year1.html","lnMedBiochem-U11-T3":"year1.html","lnMedBiochem-U11-T4":"year1.html","lnMedBiochem-U11-T5":"year1.html","lnMedBiochem-U11-T6":"year1.html","lnMedBiochem-U12":"year1.html","lnMedBiochem-U12-T1":"year1.html","lnMedBiochem-U12-T2":"year1.html","lnMedBiochem-U12-T3":"year1.html","lnMedBiochem-U12-T4":"year1.html","lnMedBiochem-U13":"year1.html","lnMedBiochem-U13-T1":"year1.html","lnMedBiochem-U13-T2":"year1.html","lnMedBiochem-U13-T3":"year1.html","lnMedBiochem-U13-T4":"year1.html","lnPharmOrgChem":"year1.html","lnPharmOrgChem-U1":"year1.html","lnPharmOrgChem-U1-T1":"year1.html","lnPharmOrgChem-U1-T2":"year1.html","lnPharmOrgChem-U1-T3":"year1.html","lnPharmOrgChem-U1-T4":"year1.html","lnPharmOrgChem-U1-T5":"year1.html","lnPharmOrgChem-U1-T6":"year1.html","lnPharmOrgChem-U1-T7":"year1.html","lnPharmOrgChem-U2":"year1.html","lnPharmOrgChem-U2-T1":"year1.html","lnPharmOrgChem-U2-T2":"year1.html","lnPharmOrgChem-U2-T3":"year1.html","lnPharmOrgChem-U2-T4":"year1.html","lnPharmOrgChem-U2-T5":"year1.html","lnPharmOrgChem-U2-T6":"year1.html","lnPharmOrgChem-U3":"year1.html","lnPharmOrgChem-U3-T1":"year1.html","lnPharmOrgChem-U3-T2":"year1.html","lnPharmOrgChem-U4":"year1.html","lnPharmOrgChem-U4-T1":"year1.html","lnPharmOrgChem-U4-T2":"year1.html","lnPharmOrgChem-U4-T3":"year1.html","lnPharmOrgChem-U5":"year1.html","lnPharmOrgChem-U5-T1":"year1.html","lnPharmOrgChem-U5-T2":"year1.html","lnPharmOrgChem-U5-T3":"year1.html","lnPharmOrgChem-U5-T4":"year1.html","lnPharmOrgChem-U5-T5":"year1.html","lnPharmOrgChem-U5-T6":"year1.html","lnPharmOrgChem-U5-T7":"year1.html","lnPharmOrgChem-U6":"year1.html","lnPharmOrgChem-U6-T1":"year1.html","lnPharmOrgChem-U6-T2":"year1.html","lnPharmOrgChem-U6-T3":"year1.html","lnPharmOrgChem-U6-T4":"year1.html","lnPharmOrgChem-U6-T5":"year1.html","lnPharmOrgChem-U6-T6":"year1.html","lnPharmOrgChem-U6-T7":"year1.html","lnPharmOrgChem-U7":"year1.html","lnPharmOrgChem-U7-T1":"year1.html","lnPharmOrgChem-U7-T2":"year1.html","lnPharmOrgChem-U7-T3":"year1.html","lnPharmOrgChem-U7-T4":"year1.html","lnPharmOrgChem-U7-T5":"year1.html","lnPharmOrgChem-U7-T6":"year1.html","lnPharmOrgChem-U7-T7":"year1.html","lnPharmOrgChem-U7-T8":"year1.html","lnPharmOrgChem-U8":"year1.html","lnPharmOrgChem-U8-T1":"year1.html","lnPharmOrgChem-U8-T2":"year1.html","lnPharmOrgChem-U8-T3":"year1.html","lnPharmOrgChem-U8-T4":"year1.html","lnPharmOrgChem-U9":"year1.html","lnPharmOrgChem-U9-T1":"year1.html","lnPharmOrgChem-U9-T2":"year1.html","lnPharmOrgChem-U9-T3":"year1.html","lnPharmOrgChem-U9-T4":"year1.html","lnPharmOrgChem-U9-T5":"year1.html","lnPharmOrgChem-U9-T6":"year1.html","lnPharmOrgChem-U9-T7":"year1.html","lnPharmOrgChem-U9-T8":"year1.html","lnPharmOrgChem-U9-T9":"year1.html","lnPharmOrgChem-U9-T10":"year1.html","lnPharmOrgChem-U10":"year1.html","lnPharmOrgChem-U10-T1":"year1.html","lnPharmOrgChem-U10-T2":"year1.html","lnPharmOrgChem-U10-T3":"year1.html","lnPharmOrgChem-U10-T4":"year1.html","lnPharmOrgChem-U10-T5":"year1.html","lnPharmOrgChem-U10-T6":"year1.html","lnPharmOrgChem-U10-T7":"year1.html","lnPharmOrgChem-U11":"year1.html","lnPharmOrgChem-U11-T1":"year1.html","lnPharmOrgChem-U11-T2":"year1.html","lnPharmOrgChem-U11-T3":"year1.html","lnPharmOrgChem-U11-T4":"year1.html","lnPharmOrgChem-U11-T5":"year1.html","lnPharmOrgChem-U11-T6":"year1.html","lnPharmOrgChem-U12":"year1.html","lnPharmOrgChem-U12-T1":"year1.html","lnPharmOrgChem-U12-T2":"year1.html","lnPharmOrgChem-U12-T3":"year1.html","lnPharmOrgChem-U12-T4":"year1.html","lnPharmOrgChem-U12-T5":"year1.html","lnPharmOrgChem-U12-T6":"year1.html","lnPharmOrgChem-U12-T7":"year1.html","lnPharmOrgChem-U12-T8":"year1.html","lnPharmOrgChem-U13":"year1.html","lnPharmOrgChem-U13-T1":"year1.html","lnPharmOrgChem-U13-T2":"year1.html","lnPharmOrgChem-U13-T3":"year1.html","lnPharmOrgChem-U13-T4":"year1.html","lnPharmOrgChem-U13-T5":"year1.html","lnPharmOrgChem-U13-T6":"year1.html","lnPharmOrgChem-U13-T7":"year1.html","lnPharmOrgChem-U13-T8":"year1.html","lnPharmOrgChem-U13-T9":"year1.html","lnPharmOrgChem-U14":"year1.html","lnPharmOrgChem-U14-T1":"year1.html","lnPharmOrgChem-U14-T2":"year1.html","lnPharmOrgChem-U14-T3":"year1.html","lnPharmOrgChem-U15":"year1.html","lnPharmOrgChem-U15-T1":"year1.html","lnPharmOrgChem-U16":"year1.html","lnPharmOrgChem-U16-T1":"year1.html","lnPharmOrgChem-U16-T2":"year1.html","lnPharmOrgChem-U16-T3":"year1.html","lnPharmOrgChem-U16-T4":"year1.html","lnPharmOrgChem-U16-T5":"year1.html","lnPharmOrgChem-U16-T6":"year1.html","lnPharmOrgChem-U16-T7":"year1.html","lnPharmOrgChem-U16-T8":"year1.html","lnPharmOrgChem-U16-T9":"year1.html","lnPharmOrgChem-U16-T10":"year1.html","lnPharmOrgChem-U16-T11":"year1.html","lnPharmOrgChem-U16-T12":"year1.html","lnPharmOrgChem-U16-T13":"year1.html","lnPharmOrgChem-U16-T14":"year1.html","lnPharmOrgChem-U16-T15":"year1.html","lnPharmOrgChem-U16-T16":"year1.html","lnPharmOrgChem-U16-T17":"year1.html","lnPharmOrgChem-U16-T18":"year1.html","lnPharmOrgChem-U16-T19":"year1.html","lnPharmOrgChem-U16-T20":"year1.html","lnPharmOrgChem-U16-T21":"year1.html","lnPharmInorgChem":"year1.html","lnPharmInorgChem-U1":"year1.html","lnPharmInorgChem-U1-T1":"year1.html","lnPharmInorgChem-U2":"year1.html","lnPharmInorgChem-U2-T1":"year1.html","lnPharmInorgChem-U3":"year1.html","lnPharmInorgChem-U3-T1":"year1.html","lnPharmInorgChem-U4":"year1.html","lnPharmInorgChem-U4-T1":"year1.html","lnPharmInorgChem-U5":"year1.html","lnPharmInorgChem-U5-T1":"year1.html","lnPharmInorgChem-U6":"year1.html","lnPharmInorgChem-U6-T1":"year1.html","lnPharmInorgChem-U7":"year1.html","lnPharmInorgChem-U7-T1":"year1.html","lnPharmInorgChem-U8":"year1.html","lnPharmInorgChem-U8-T1":"year1.html","lnPharmInorgChem-U9":"year1.html","lnPharmInorgChem-U9-T1":"year1.html","lnPharmInorgChem-U10":"year1.html","lnPharmInorgChem-U10-T1":"year1.html","lnPharmInorgChem-U11":"year1.html","lnPharmInorgChem-U11-T1":"year1.html","lnPharmInorgChem-U12":"year1.html","lnPharmInorgChem-U12-T1":"year1.html","lnPharmInorgChem-U13":"year1.html","lnPharmInorgChem-U13-T1":"year1.html","lnPharmInorgChem-U14":"year1.html","lnPharmInorgChem-U14-T1":"year1.html","lnPharmInorgChem-U15":"year1.html","lnPharmInorgChem-U15-T1":"year1.html","lnPharmInorgChem-U16":"year1.html","lnPharmInorgChem-U16-T1":"year1.html","lnPharmInorgChem-U17":"year1.html","lnPharmInorgChem-U17-T1":"year1.html","lnPharmInorgChem-U18":"year1.html","lnPharmInorgChem-U18-T1":"year1.html","lnPharmInorgChem-U19":"year1.html","lnPharmInorgChem-U19-T1":"year1.html","lnPharmInorgChem-U20":"year1.html","lnPharmInorgChem-U20-T1":"year1.html","lnPharmInorgChem-U21":"year1.html","lnPharmInorgChem-U21-T1":"year1.html","lnRemedialMath":"year1.html","lnRemedialMath-U1":"year1.html","lnRemedialMath-U1-T1":"year1.html","lnRemedialMath-U1-T2":"year1.html","lnRemedialMath-U2":"year1.html","lnRemedialMath-U2-T1":"year1.html","lnRemedialMath-U2-T2":"year1.html","lnRemedialMath-U3":"year1.html","lnRemedialMath-U3-T1":"year1.html","lnRemedialMath-U3-T2":"year1.html","lnRemedialMath-U3-T3":"year1.html","lnRemedialMath-U3-T4":"year1.html","lnRemedialMath-U4":"year1.html","lnRemedialMath-U4-T1":"year1.html","lnRemedialMath-U4-T2":"year1.html","lnRemedialMath-U4-T3":"year1.html","lnRemedialMath-U4-T4":"year1.html","lnRemedialMath-U4-T5":"year1.html","lnRemedialMath-U4-T6":"year1.html","lnRemedialMath-U4-T7":"year1.html","lnRemedialMath-U4-T8":"year1.html","lnRemedialMath-U4-T9":"year1.html","lnRemedialMath-U5":"year1.html","lnRemedialMath-U5-T1":"year1.html","lnRemedialMath-U5-T2":"year1.html","lnRemedialMath-U5-T3":"year1.html","lnRemedialMath-U5-T4":"year1.html","lnRemedialMath-U6":"year1.html","lnRemedialMath-U6-T1":"year1.html","lnRemedialMath-U6-T2":"year1.html","lnRemedialMath-U6-T3":"year1.html","lnRemedialMath-U6-T4":"year1.html","lnRemedialMath-U6-T5":"year1.html","lnRemedialMath-U6-T6":"year1.html","lnRemedialMath-U7":"year1.html","lnRemedialMath-U7-T1":"year1.html","lnRemedialMath-U7-T2":"year1.html","lnRemedialMath-U7-T3":"year1.html","lnYear2":"year2.html","lnPathophysiology":"year2.html","lnPathophysiology-U1":"year2.html","lnPathophysiology-U1-T1":"year2.html","lnPathophysiology-U1-T2":"year2.html","lnPathophysiology-U2":"year2.html","lnPathophysiology-U2-T1":"year2.html","lnPathophysiology-U2-T2":"year2.html","lnPathophysiology-U3":"year2.html","lnPathophysiology-U3-T1":"year2.html","lnPathophysiology-U3-T2":"year2.html","lnPathophysiology-U3-T3":"year2.html","lnPathophysiology-U3-T4":"year2.html","lnPathophysiology-U4":"year2.html","lnPathophysiology-U4-T1":"year2.html","lnPathophysiology-U5":"year2.html","lnPathophysiology-U5-T1":"year2.html","lnPathophysiology-U6":"year2.html","lnPathophysiology-U6-T1":"year2.html","lnPathophysiology-U7":"year2.html","lnPathophysiology-U7-T1":"year2.html","lnPathophysiology-U7-T2":"year2.html","lnPathophysiology-U8":"year2.html","lnPathophysiology-U8-T1":"year2.html","lnPathophysiology-U8-T2":"year2.html","lnPathophysiology-U8-T3":"year2.html","lnPathophysiology-U8-T4":"year2.html","lnPathophysiology-U8-T5":"year2.html","lnPathophysiology-U8-T6":"year2.html","lnPathophysiology-U8-T7":"year2.html","lnPathophysiology-U8-T8":"year2.html","lnPathophysiology-U8-T9":"year2.html","lnPathophysiology-U8-T10":"year2.html","lnPathophysiology-U8-T11":"year2.html","lnPathophysiology-U9":"year2.html","lnPathophysiology-U9-T1":"year2.html","lnPharmMicrobiology":"year2.html","lnPharmMicrobiology-U1":"year2.html","lnPharmMicrobiology-U1-T1":"year2.html","lnPharmMicrobiology-U2":"year2.html","lnPharmMicrobiology-U2-T1":"year2.html","lnPharmMicrobiology-U3":"year2.html","lnPharmMicrobiology-U3-T1":"year2.html","lnPharmMicrobiology-U4":"year2.html","lnPharmMicrobiology-U4-T1":"year2.html","lnPharmMicrobiology-U5":"year2.html","lnPharmMicrobiology-U5-T1":"year2.html","lnPharmMicrobiology-U6":"year2.html","lnPharmMicrobiology-U6-T1":"year2.html","lnPharmMicrobiology-U7":"year2.html","lnPharmMicrobiology-U7-T1":"year2.html","lnPharmMicrobiology-U8":"year2.html","lnPharmMicrobiology-U8-T1":"year2.html","lnPharmMicrobiology-U9":"year2.html","lnPharmMicrobiology-U9-T1":"year2.html","lnPharmMicrobiology-U10":"year2.html","lnPharmMicrobiology-U10-T1":"year2.html","lnPharmacognosy":"year2.html","lnPharmacognosy-U1":"year2.html","lnPharmacognosy-U1-T1":"year2.html","lnPharmacognosy-U2":"year2.html","lnPharmacognosy-U2-T1":"year2.html","lnPharmacognosy-U3":"year2.html","lnPharmacognosy-U3-T1":"year2.html","lnPharmacognosy-U4":"year2.html","lnPharmacognosy-U4-T1":"year2.html","lnPharmacognosy-U5":"year2.html","lnPharmacognosy-U5-T1":"year2.html","lnPharmacognosy-U6":"year2.html","lnPharmacognosy-U6-T1":"year2.html","lnPharmacognosy-U7":"year2.html","lnPharmacognosy-U7-T1":"year2.html","lnPharmacognosy-U8":"year2.html","lnPharmacognosy-U8-T1":"year2.html","lnPharmacognosy-U9":"year2.html","lnPharmacognosy-U9-T1":"year2.html","lnPharmacognosy-U10":"year2.html","lnPharmacognosy-U10-T1":"year2.html","lnPharmacognosy-U11":"year2.html","lnPharmacognosy-U11-T1":"year2.html","lnPharmacognosy-U12":"year2.html","lnPharmacognosy-U12-T1":"year2.html","lnPharmacognosy-U13":"year2.html","lnPharmacognosy-U13-T1":"year2.html","lnPharmacognosy-U14":"year2.html","lnPharmacognosy-U14-T1":"year2.html","lnPharmacognosy-U15":"year2.html","lnPharmacognosy-U15-T1":"year2.html","lnPharmacognosy-U16":"year2.html","lnPharmacognosy-U16-T1":"year2.html","lnPharmacologyI":"year2.html","lnPharmacologyI-U1":"year2.html","lnPharmacologyI-U1-T1":"year2.html","lnPharmacologyI-U2":"year2.html","lnPharmacologyI-U2-T1":"year2.html","lnPharmacologyI-U2-T2":"year2.html","lnPharmacologyI-U2-T3":"year2.html","lnPharmacologyI-U2-T4":"year2.html","lnPharmacologyI-U2-T5":"year2.html","lnPharmacologyI-U2-T6":"year2.html","lnPharmacologyI-U3":"year2.html","lnPharmacologyI-U3-T1":"year2.html","lnPharmacologyI-U3-T2":"year2.html","lnPharmacologyI-U3-T3":"year2.html","lnPharmacologyI-U3-T4":"year2.html","lnPharmacologyI-U3-T5":"year2.html","lnPharmacologyI-U4":"year2.html","lnPharmacologyI-U4-T1":"year2.html","lnPharmacologyI-U4-T2":"year2.html","lnPharmacologyI-U4-T3":"year2.html","lnPharmacologyI-U4-T4":"year2.html","lnPharmacologyI-U4-T5":"year2.html","lnPharmacologyI-U4-T6":"year2.html","lnPharmacologyI-U4-T7":"year2.html","lnPharmacologyI-U4-T8":"year2.html","lnPharmacologyI-U5":"year2.html","lnPharmacologyI-U5-T1":"year2.html","lnPharmacologyI-U5-T2":"year2.html","lnPharmacologyI-U5-T3":"year2.html","lnPharmacologyI-U5-T4":"year2.html","lnPharmacologyI-U5-T5":"year2.html","lnPharmacologyI-U6":"year2.html","lnPharmacologyI-U6-T1":"year2.html","lnPharmacologyI-U6-T2":"year2.html","lnPharmacologyI-U6-T3":"year2.html","lnPharmacologyI-U6-T4":"year2.html","lnPharmacologyI-U7":"year2.html","lnPharmacologyI-U7-T1":"year2.html","lnPharmacologyI-U7-T2":"year2.html","lnPharmacologyI-U7-T3":"year2.html","lnCommunityPharmacy":"year2.html","lnCommunityPharmacy-U1":"year2.html","lnCommunityPharmacy-U1-T1":"year2.html","lnCommunityPharmacy-U2":"year2.html","lnCommunityPharmacy-U2-T1":"year2.html","lnCommunityPharmacy-U2-T2":"year2.html","lnCommunityPharmacy-U2-T3":"year2.html","lnCommunityPharmacy-U2-T4":"year2.html","lnCommunityPharmacy-U2-T5":"year2.html","lnCommunityPharmacy-U3":"year2.html","lnCommunityPharmacy-U3-T1":"year2.html","lnCommunityPharmacy-U4":"year2.html","lnCommunityPharmacy-U4-T1":"year2.html","lnCommunityPharmacy-U5":"year2.html","lnCommunityPharmacy-U5-T1":"year2.html","lnCommunityPharmacy-U6":"year2.html","lnCommunityPharmacy-U6-T1":"year2.html","lnCommunityPharmacy-U7":"year2.html","lnCommunityPharmacy-U7-T1":"year2.html","lnCommunityPharmacy-U8":"year2.html","lnCommunityPharmacy-U8-T1":"year2.html","lnCommunityPharmacy-U9":"year2.html","lnCommunityPharmacy-U9-T1":"year2.html","lnCommunityPharmacy-U10":"year2.html","lnCommunityPharmacy-U10-T1":"year2.html","lnCommunityPharmacy-U10-T2":"year2.html","lnCommunityPharmacy-U10-T3":"year2.html","lnCommunityPharmacy-U10-T4":"year2.html","lnCommunityPharmacy-U11":"year2.html","lnCommunityPharmacy-U11-T1":"year2.html","lnCommunityPharmacy-U12":"year2.html","lnCommunityPharmacy-U12-T1":"year2.html","lnCommunityPharmacy-U13":"year2.html","lnCommunityPharmacy-U13-T1":"year2.html","lnPharmacotherapeuticsI":"year2.html","lnPharmacotherapeuticsI-U1":"year2.html","lnPharmacotherapeuticsI-U1-T1":"year2.html","lnPharmacotherapeuticsI-U2":"year2.html","lnPharmacotherapeuticsI-U2-T1":"year2.html","lnPharmacotherapeuticsI-U2-T2":"year2.html","lnPharmacotherapeuticsI-U3":"year2.html","lnPharmacotherapeuticsI-U3-T1":"year2.html","lnPharmacotherapeuticsI-U3-T2":"year2.html","lnPharmacotherapeuticsI-U3-T3":"year2.html","lnPharmacotherapeuticsI-U4":"year2.html","lnPharmacotherapeuticsI-U4-T1":"year2.html","lnPharmacotherapeuticsI-U5":"year2.html","lnPharmacotherapeuticsI-U5-T1":"year2.html","lnYear3":"year3.html","lnYear4":"year4.html","lnPharmaco3":"year4.html","lnHospitalPharmacy":"year4.html","lnClinicalPharmacy":"year4.html","lnCP-Basics":"year4.html","lnCP-Activities":"year4.html","lnCP-PatientData":"year4.html","lnCP-LabTests":"year4.html","lnCP-DrugInfo":"year4.html","lnCP-Pharmacovigilance":"year4.html","lnCP-Communication":"year4.html","lnCP-PharmCare":"year4.html","lnCP-MedErrors":"year4.html","lnCP-LitEval":"year4.html","lnBiostat":"year4.html","lnBS-ResearchMeth":"year4.html","lnBS-Biostatistics":"year4.html","lnBS-DataGraphics":"year4.html","lnBS-HypothesisTesting":"year4.html","lnBS-Epidemiology":"year4.html","lnBS-ComputerApps":"year4.html","lnBiopharma":"year4.html","lnBP-Basics":"year4.html","lnBP-PKFundamentals":"year4.html","lnBP-OneCompartment":"year4.html","lnBP-MultiCompartment":"year4.html","lnBP-DosageRegimens":"year4.html","lnBP-NonlinearPK":"year4.html","lnBP-NoncompartmentalPK":"year4.html","lnBP-Bioavailability":"year4.html","lnClinTox":"year4.html","lnCT-GeneralPrinciples":"year4.html","lnCT-Antidotes":"year4.html","lnCT-SupportiveCare":"year4.html","lnCT-GutDecontamination":"year4.html","lnCT-EliminationEnhancement":"year4.html","lnCT-Toxicokinetics":"year4.html","lnCT-AcutePoisoning":"year4.html","lnCT-ChronicPoisoning":"year4.html","lnCT-SnakeBite":"year4.html","lnCT-PlantPoisoning":"year4.html","lnCT-FoodPoisoning":"year4.html","lnCT-Envenomation":"year4.html","lnHP-OrgFunctions":"year4.html","lnHP-PharmacyOrg":"year4.html","lnHP-Budget":"year4.html","lnHP-DrugPolicy":"year4.html","lnHP-Services":"year4.html","lnHP-Manufacture":"year4.html","lnHP-CPD":"year4.html","lnHP-Radio":"year4.html","lnHP-ProRelations":"year4.html","lnGastro":"year4.html","lnHaemato":"year4.html","lnNervous":"year4.html","lnPsychiatry":"year4.html","lnPain":"year4.html","lnEBM":"year4.html","lnYear5":"year5.html","lnCR":"year5.html","lnCR-DataManagement":"year5.html","lnYear6":"year6.html"};

        var Nav = (function () {
            var BASE = 'lecturerNotes';
            var _history = [BASE];
            var _scrollMap = {};
            var _activating = false;

            function _activate(pageId, restoreScroll, isBack) {
                var targetPage = document.getElementById(pageId);
                if (!targetPage) {
                    var otherFile = LN_FILE_MAP[pageId];
                    if (otherFile && otherFile !== LN_CURRENT_FILE) {
                        window.location.href = otherFile + '#' + pageId;
                        return false;
                    }
                    console.error('Nav: page not found —', pageId);
                    appState.showNotification('Page "' + pageId + '" not found', 'error');
                    return false;
                }

                var cur = appState.currentPage;
                if (cur) {
                    var curEl = document.getElementById(cur);
                    if (curEl) _scrollMap[cur] = curEl.scrollTop;
                }

                document.querySelectorAll('.page').forEach(function (p) {
                    p.classList.remove('active', 'slide-back');
                });

                if (isBack) {
                    targetPage.classList.add('slide-back');
                    void targetPage.offsetWidth;
                    targetPage.classList.remove('slide-back');
                }
                targetPage.classList.add('active');
                targetPage.style.top = '0';

                appState.currentPage = pageId;

                if (restoreScroll && _scrollMap[pageId] !== undefined) {
                    targetPage.scrollTop = _scrollMap[pageId];
                } else if (!restoreScroll) {
                    targetPage.scrollTop = 0;
                    delete _scrollMap[pageId];
                }

                return true;
            }

            function go(pageId) {
                if (_activating) return;
                _activating = true;
                try {
                    if (!pageId) { _activating = false; return; }
                    if (_history.length && _history[_history.length - 1] === pageId) {
                        _activating = false; return;
                    }
                    if (!_activate(pageId, false, false)) { _activating = false; return; }

                    _history.push(pageId);
                    if (_history.length > 30) _history.shift();

                    if (pageId !== BASE) {
                        window.history.pushState({ pharmdNav: pageId }, '', '');
                    }
                } catch (e) {
                    console.error('Nav.go error:', e);
                    appState.showNotification('Navigation error', 'error');
                } finally {
                    _activating = false;
                }
            }

            function back() {
                if (_activating) return;
                if (_closeTopOverlay()) return;

                if (_history.length > 1) {
                    _history.pop();
                    var prev = _history[_history.length - 1];
                    _activating = true;
                    try { _activate(prev, true, true); } finally { _activating = false; }
                } else {
                    // At the base page — leave the Pharm D Notes document
                    // and return to the main app, same destination as
                    // clicking "Pharm D Notes" got you here from.
                    window.location.href = 'index.html';
                }
            }

            // Only overlay in this scoped page is the PDF viewer modal.
            function _closeTopOverlay() {
                var pdfModal = document.getElementById('lnPdfModal');
                if (pdfModal && pdfModal.style.display !== 'none') {
                    closeLnPdf();
                    return true;
                }
                return false;
            }

            function currentPage() { return _history[_history.length - 1] || BASE; }
            function stackDepth() { return _history.length; }

            return { go: go, back: back, currentPage: currentPage, stackDepth: stackDepth, _closeTopOverlay: _closeTopOverlay };
        })();

        function showPage(pageId) { Nav.go(pageId); }
        function goBack()         { Nav.back(); }

        // ═══════════════════════════════════════════════════════════════
        // BOOKMARK SYSTEM — bookmark-icon toggle on every subject/unit/topic page,
        // persisted to localStorage, listed on the "Saved" page (lnSaved).
        // Works generically across all ln* pages so it doesn't need to be
        // hand-added to each of the 150+ subject/unit/topic pages.
        // ═══════════════════════════════════════════════════════════════
        var LN_BM_KEY = 'ln_bookmarks_v1';
        var LN_BM_EXCLUDE = { lecturerNotes: 1, lnSaved: 1, lnYear1: 1, lnYear2: 1, lnYear3: 1, lnYear4: 1, lnYear5: 1, lnYear6: 1 };

        function lnGetBookmarks() {
            try { return JSON.parse(localStorage.getItem(LN_BM_KEY) || '{}'); } catch (e) { return {}; }
        }
        function lnSaveBookmarks(obj) {
            try { localStorage.setItem(LN_BM_KEY, JSON.stringify(obj)); } catch (e) {}
        }
        function lnIsBookmarked(id) { return !!lnGetBookmarks()[id]; }

        function lnBookmarkType(id) {
            if (/-U\d+-T\d+$/.test(id)) return 'Topic';
            if (/-U\d+$/.test(id)) return 'Unit';
            if (id.indexOf('-') !== -1) return 'Topic';
            return 'Subject';
        }

        function lnEsc(s) {
            return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        function lnBookmarkIcon(filled) {
            return '<svg viewBox="0 0 24 24" width="16" height="16" style="display:block" fill="' +
                (filled ? 'currentColor' : 'none') +
                '" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>';
        }
        function lnUpdateBookmarkBtn(btn, isOn) {
            btn.innerHTML = lnBookmarkIcon(isOn);
            btn.style.background = isOn ? 'rgba(255,255,255,0.34)' : 'rgba(255,255,255,0.16)';
            btn.setAttribute('aria-pressed', isOn ? 'true' : 'false');
        }

        function lnToggleBookmark(id, meta, btnEl) {
            var bms = lnGetBookmarks();
            var nowOn;
            if (bms[id]) { delete bms[id]; nowOn = false; }
            else { bms[id] = meta; nowOn = true; }
            lnSaveBookmarks(bms);
            if (btnEl) lnUpdateBookmarkBtn(btnEl, nowOn);
            var savedPage = document.getElementById('lnSaved');
            if (savedPage && savedPage.classList.contains('active')) lnRenderSavedList();
            if (typeof appState !== 'undefined' && appState.showNotification) {
                appState.showNotification(nowOn ? 'Saved to bookmarks' : 'Removed from bookmarks', 'success', 1400);
            }
        }

        function lnInjectBookmarkButtons() {
            document.querySelectorAll('.page').forEach(function (pageEl) {
                var id = pageEl.id;
                if (!id || id.indexOf('ln') !== 0 || LN_BM_EXCLUDE[id]) return;

                var header = pageEl.querySelector('div[style*="linear-gradient(135deg"] > div[style*="display:flex"]');
                if (!header || header.querySelector('.ln-bm-btn')) return;

                var titleEl, subEl;
                header.querySelectorAll(':scope > div').forEach(function (c) {
                    var inner = c.querySelectorAll(':scope > div');
                    if (inner.length >= 2 && !titleEl) { titleEl = inner[0]; subEl = inner[1]; }
                });
                var title = titleEl ? titleEl.textContent.trim() : id;
                var subtitle = subEl ? subEl.textContent.trim() : '';
                var meta = { title: title, subtitle: subtitle, type: lnBookmarkType(id) };

                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'ln-bm-btn';
                btn.setAttribute('aria-label', 'Bookmark this page');
                btn.style.cssText = 'margin-left:auto;flex-shrink:0;background:rgba(255,255,255,0.16);border:none;border-radius:8px;width:34px;height:34px;font-size:1.15rem;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#fff;transition:transform .15s ease, background .15s ease;';
                btn.addEventListener('mousedown', function () { btn.style.transform = 'scale(0.88)'; });
                ['mouseup', 'mouseleave'].forEach(function (ev) {
                    btn.addEventListener(ev, function () { btn.style.transform = 'scale(1)'; });
                });
                lnUpdateBookmarkBtn(btn, lnIsBookmarked(id));

                btn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    lnToggleBookmark(id, meta, btn);
                });

                header.appendChild(btn);
            });
        }

        function lnRenderSavedList() {
            var container = document.getElementById('lnSavedList');
            if (!container) return;
            var bms = lnGetBookmarks();
            var ids = Object.keys(bms);

            if (!ids.length) {
                container.innerHTML =
                    '<div style="text-align:center;padding:2.5rem 1rem;color:var(--text-secondary);">' +
                        '<div style="font-size:2rem;margin-bottom:0.5rem;">🔖</div>' +
                        '<div style="font-size:0.85rem;font-weight:600;">No bookmarks yet</div>' +
                        '<div style="font-size:0.72rem;margin-top:0.35rem;opacity:0.85;">Tap the bookmark icon on any subject, unit or topic page to save it here.</div>' +
                    '</div>';
                return;
            }

            ids.sort(function (a, b) { return (bms[a].title || '').localeCompare(bms[b].title || ''); });

            var badgeColor = { Subject: '#0ea5e9', Unit: '#8b5cf6', Topic: '#10b981' };
            container.innerHTML = '';
            ids.forEach(function (id) {
                var meta = bms[id];
                var color = badgeColor[meta.type] || '#0ea5e9';
                var row = document.createElement('div');
                row.style.cssText = 'background:var(--surface);border:1px solid var(--border);border-radius:var(--border-radius);padding:0.85rem 1rem;display:flex;align-items:center;gap:0.75rem;cursor:pointer;box-shadow:var(--shadow);transition:var(--transition);';
                row.addEventListener('mouseover', function () { row.style.borderColor = '#0ea5e9'; });
                row.addEventListener('mouseout', function () { row.style.borderColor = 'var(--border)'; });

                row.innerHTML =
                    '<div style="flex:1;min-width:0;">' +
                        '<span style="font-size:0.6rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;padding:0.15rem 0.5rem;border-radius:20px;background:' + color + '1a;color:' + color + ';">' + lnEsc(meta.type || 'Topic') + '</span>' +
                        '<div style="font-size:0.88rem;font-weight:700;color:var(--text-primary);line-height:1.3;margin-top:0.35rem;">' + lnEsc(meta.title || id) + '</div>' +
                        (meta.subtitle ? '<div style="font-size:0.7rem;color:var(--text-secondary);margin-top:0.15rem;">' + lnEsc(meta.subtitle) + '</div>' : '') +
                    '</div>' +
                    '<button type="button" class="ln-bm-remove" aria-label="Remove bookmark" style="flex-shrink:0;background:none;border:none;color:#0ea5e9;cursor:pointer;padding:0.3rem;display:flex;align-items:center;">' + lnBookmarkIcon(true) + '</button>';

                row.addEventListener('click', function (e) {
                    if (e.target.closest('.ln-bm-remove')) return;
                    showPage(id);
                });
                row.querySelector('.ln-bm-remove').addEventListener('click', function (e) {
                    e.stopPropagation();
                    lnToggleBookmark(id, meta);
                    lnRenderSavedList();
                    var srcPage = document.getElementById(id);
                    var srcBtn = srcPage ? srcPage.querySelector('.ln-bm-btn') : null;
                    if (srcBtn) lnUpdateBookmarkBtn(srcBtn, false);
                });

                container.appendChild(row);
            });
        }

        // ═══════════════════════════════════════════════════════════════
        // SUBJECT OVERVIEW — a short "About this subject" blurb injected
        // above the existing units/topics list on every top-level subject
        // page. The units/topics list itself is left completely untouched
        // (still visible right below Overview, same styling and links).
        // Done generically via JS so none of the 25 subject pages needed
        // hand-editing.
        // ═══════════════════════════════════════════════════════════════
        var LN_SUBJECT_ABOUT = {
            lnCR: "Clinical Research covers how drug trials and clinical studies are designed, conducted and reported — including the data management and regulatory standards that keep results reliable.",
            lnHAP: "Human Anatomy and Physiology covers the structure and function of the human body, from cells and tissues to major organ systems — the foundation for understanding how drugs act and how disease develops.",
            lnPharmaceutics: "Pharmaceutics covers the science of formulating drugs into safe, effective dosage forms — tablets, capsules, liquids and sterile products — and how they're manufactured and quality-tested.",
            lnMedBiochem: "Medicinal Biochemistry explores the chemical processes inside the body — metabolism, enzymes and biomolecules — that explain how drugs are absorbed, transformed and eliminated.",
            lnPharmOrgChem: "Pharmaceutical Organic Chemistry covers the structure, reactions and synthesis of organic compounds that form the building blocks of most drug molecules.",
            lnPharmInorgChem: "Pharmaceutical Inorganic Chemistry covers inorganic compounds used as medicines and pharmaceutical excipients, along with their preparation, standards and quality testing.",
            lnRemedialMath: "Remedial Mathematics / Biology builds the core math and biology foundations — calculations, units and basic biological concepts — needed for the rest of the PharmD curriculum.",
            lnPathophysiology: "Pathophysiology explains how diseases develop and progress in the body, giving you the clinical reasoning needed to understand why drugs are used the way they are.",
            lnPharmMicrobiology: "Pharmaceutical Microbiology covers microorganisms relevant to pharmacy — infection, sterilization and the principles behind antimicrobial drugs and safe drug manufacturing.",
            lnPharmacognosy: "Pharmacognosy & Phytopharmaceuticals covers medicines derived from natural sources, including their identification, active constituents and therapeutic uses.",
            lnPharmacologyI: "Pharmacology-I introduces how drugs interact with the body — mechanisms of action, dosing principles and adverse effects — the foundation for rational drug therapy.",
            lnCommunityPharmacy: "Community Pharmacy covers pharmacy practice in the retail/community setting — patient counseling, dispensing, and the day-to-day responsibilities of a community pharmacist.",
            lnPharmacotherapeuticsI: "Pharmacotherapeutics-I applies pharmacology and pathophysiology to the treatment of specific diseases, covering drug selection, dosing and monitoring for common conditions.",
            lnPharmaco3: "Pharmacotherapeutics III covers disease-specific drug therapy across major organ systems, building the clinical decision-making skills needed for real-world patient care.",
            lnHospitalPharmacy: "Hospital Pharmacy covers pharmacy practice within hospital settings — medication management, clinical services and the systems that keep inpatient drug therapy safe and effective.",
            lnClinicalPharmacy: "Clinical Pharmacy covers direct patient-care skills — medication review, therapeutic monitoring and collaborating with healthcare teams to optimize drug therapy.",
            lnBiostat: "Biostatistics & Research Methodology covers the statistical tools and study designs used to evaluate drug therapy and interpret pharmacy research.",
            lnBiopharma: "Biopharmaceutics & Pharmacokinetics covers how the body absorbs, distributes, metabolizes and eliminates drugs, and how that shapes dosing and drug formulation.",
            lnClinTox: "Clinical Toxicology covers the diagnosis and management of poisoning and drug toxicity, including antidotes, decontamination and supportive care.",
            lnGastro: "Gastrointestinal System covers the diagnosis and drug treatment of GI conditions such as peptic ulcer disease, GERD, IBD and liver disorders.",
            lnHaemato: "Haematological System covers blood disorders and their drug treatment, including anaemia, clotting disorders and other conditions affecting blood cells.",
            lnNervous: "Nervous System covers drug therapy for neurological conditions, from mechanisms of disease to the medications used to manage them.",
            lnPsychiatry: "Psychiatry Disorders covers the diagnosis and pharmacological management of mental health conditions, including antidepressants, antipsychotics and mood stabilizers.",
            lnPain: "Pain Management covers the assessment and drug treatment of acute and chronic pain, including analgesic selection and safe opioid use.",
            lnEBM: "Evidence Based Medicine covers how to critically appraise clinical research and apply the best available evidence to real-world patient care decisions."
        };

        function lnInjectSubjectTabs() {
            Object.keys(LN_SUBJECT_ABOUT).forEach(function (id) {
                var pageEl = document.getElementById(id);
                if (!pageEl || pageEl.querySelector('.ln-subject-about')) return;

                var wrap = pageEl.querySelector(':scope > div');
                var banner = wrap ? wrap.querySelector(':scope > div[style*="linear-gradient(135deg"]') : null;
                if (!banner) return;

                var label = banner.nextElementSibling;
                if (!label) return;

                var overviewBlock = document.createElement('div');
                overviewBlock.className = 'ln-subject-about';
                overviewBlock.style.cssText = 'background:var(--surface);border:1px solid var(--border);border-radius:var(--border-radius);padding:0.9rem 1rem;margin-bottom:1.1rem;box-shadow:var(--shadow);';
                overviewBlock.innerHTML =
                    '<div style="font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;color:#0284c7;margin-bottom:0.4rem;">Overview</div>' +
                    '<div style="font-size:0.82rem;line-height:1.65;color:var(--text-secondary);">' + lnEsc(LN_SUBJECT_ABOUT[id]) + '</div>';

                wrap.insertBefore(overviewBlock, label);
            });
        }

        // ── Init ──────────────────────────────────────────────────────
        document.addEventListener('DOMContentLoaded', function () {
            try {
                var base = document.getElementById('lecturerNotes');
                if (base) {
                    base.classList.add('active');
                    base.style.top = '0';
                }
                appState.currentPage = 'lecturerNotes';

                lnInjectBookmarkButtons();
                lnInjectSubjectTabs();

                // Landed here via a cross-file link (e.g. year1.html
                // redirected to year2.html#lnPathophysiology) — jump
                // straight to that page instead of staying on the
                // "Select a Year" base page.
                var deepLinkId = window.location.hash ? window.location.hash.slice(1) : '';
                if (deepLinkId && document.getElementById(deepLinkId)) {
                    showPage(deepLinkId);
                }

                window.addEventListener('popstate', function () {
                    var overlayWasClosed = Nav._closeTopOverlay();
                    if (overlayWasClosed) {
                        window.history.pushState({ pharmdNav: 'overlay-closed' }, '', '');
                        return;
                    }
                    Nav.back();
                });
            } catch (e) {
                console.error('Pharm D Notes init error:', e);
            }
        });


    // ════ Pharm D Notes ══════════════════════════════════

    // ── Pharm D Notes — PDF.js Viewer ───────────────────────────────
    var LN_PDF_MAP = {
        // ── Gastrointestinal System ───────────────────────────────────
        'peptic-ulcer':    { title: 'Peptic Ulcer Disease',                pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/gastrointestinal system/peptic ulcer disease.pdf' },
        'gerd':            { title: 'Gastro Esophageal Reflux Disease',    pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/gastrointestinal system/gastro esophageal reflux disease.pdf' },
        'ibd':             { title: 'Inflammatory Bowel Disease',           pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/gastrointestinal system/inflammatory bowel disease.pdf' },
        'alcoholic-liver': { title: 'Alcoholic Liver Disease',             pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/gastrointestinal system/alcoholic liver disease.pdf' },
        'viral-hepatitis': { title: 'Viral Hepatitis Including Jaundice',  pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/gastrointestinal system/viral hepatitis including jaundice.pdf' },
        'drug-liver':      { title: 'Drug Induced Liver Disorders',        pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/gastrointestinal system/drug induced liver disorders.pdf' },

        // ── Haematological System ─────────────────────────────────────
        'anaemias':        { title: 'Anaemias',                            pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/haematological system/anaemias.pdf' },
        'vte':             { title: 'Venous Thromboembolism',              pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/haematological system/venous thromboembolism.pdf' },
        'drug-blood':      { title: 'Drug Induced Blood Disorders',        pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/haematological system/drug induced blood disorders.pdf' },

        // ── Nervous System ────────────────────────────────────────────
        'epilepsy':        { title: 'Epilepsy',                            pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/nervous system/epilepsy.pdf' },
        'parkinsonism':    { title: 'Parkinsonism',                        pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/nervous system/parkinsonism.pdf' },
        'stroke':          { title: 'Stroke',                              pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/nervous system/stroke.pdf' },
        'alzheimers':      { title: "Alzheimer's Disease",                 pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/nervous system/alzheimers disease.pdf' },

        // ── Psychiatry Disorders ──────────────────────────────────────
        'schizophrenia':       { title: 'Schizophrenia',                  pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/psychiatry disorders/schizophrenia.pdf' },
        'affective-disorders': { title: 'Affective Disorders',            pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/psychiatry disorders/affective disorders.pdf' },
        'anxiety-disorders':   { title: 'Anxiety Disorders',              pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/psychiatry disorders/anxiety disorders.pdf' },
        'sleep-disorders':     { title: 'Sleep Disorders',                pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/psychiatry disorders/sleep disorders.pdf' },
        'ocd':                 { title: 'Obsessive Compulsive Disorder',  pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/psychiatry disorders/obsessive compulsive disorder.pdf' },

        // ── Pain Management ───────────────────────────────────────────
        'pain-pathways':   { title: 'Pain Pathways',                       pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/pain management/pain pathways.pdf' },
        'neuralgias':      { title: 'Neuralgias',                          pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/pain management/neuralgias.pdf' },
        'headaches':       { title: 'Headaches',                           pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/pain management/headaches.pdf' },

        // ── Evidence Based Medicine ───────────────────────────────────
        'ebm':             { title: 'Evidence Based Medicine',             pdf: 'pharmd-notes/4th year/pharmacotherapeutics iii/evidence based medicine/evidence based medicine.pdf' },

        // ── Hospital Organisation & Functions ─────────────────────────
        'hp-org-functions':       { title: 'Hospital Organisation and Functions',                          pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital organisation and functions/hospital organisation and functions.pdf' },

        // ── Hospital Pharmacy Organisation & Management ───────────────
        'hp-org-struct':          { title: 'Organisational Structure, Staff, Infrastructure & Workload Statistics', pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy organisation and management/organisational structure staff infrastructure workload statistics.pdf' },
        'hp-materials-finance':   { title: 'Management of Materials and Finance',                          pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy organisation and management/management of materials and finance.pdf' },
        'hp-roles-responsibilities': { title: 'Roles and Responsibilities of Hospital Pharmacist',        pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy organisation and management/roles and responsibilities of hospital pharmacist.pdf' },

        // ── Budget Preparation & Implementation ───────────────────────
        'hp-budget':              { title: 'Budget Preparation and Implementation',                        pdf: 'pharmd-notes/4th year/hospital pharmacy/budget preparation and implementation/budget preparation and implementation.pdf' },

        // ── Hospital Drug Policy ──────────────────────────────────────
        'hp-ptc':                 { title: 'Pharmacy and Therapeutic Committee (PTC)',                     pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital drug policy/pharmacy and therapeutic committee ptc.pdf' },
        'hp-formulary':           { title: 'Hospital Formulary',                                           pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital drug policy/hospital formulary.pdf' },
        'hp-infection-committee': { title: 'Infection Committee',                                          pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital drug policy/infection committee.pdf' },
        'hp-research-ethics':     { title: 'Research and Ethical Committee',                               pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital drug policy/research and ethical committee.pdf' },
        'hp-therapeutic-guidelines': { title: 'Developing Therapeutic Guidelines',                        pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital drug policy/developing therapeutic guidelines.pdf' },
        'hp-newsletter':          { title: 'Hospital Pharmacy Communication Newsletter',                   pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital drug policy/hospital pharmacy communication newsletter.pdf' },

        // ── Hospital Pharmacy Services ────────────────────────────────
        'hp-procurement':         { title: 'Procurement and Warehousing of Drugs and Pharmaceuticals',    pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/procurement and warehousing of drugs and pharmaceuticals.pdf' },
        'hp-inventory-def':       { title: 'Inventory Control Definition',                                 pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/inventory control definition.pdf' },
        'hp-abc':                 { title: 'ABC Analysis',                                                 pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/abc analysis.pdf' },
        'hp-ved':                 { title: 'VED Analysis',                                                 pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/ved analysis.pdf' },
        'hp-eoq':                 { title: 'Economic Order Quantity (EOQ)',                                pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/economic order quantity eoq.pdf' },
        'hp-lead-time':           { title: 'Lead Time',                                                    pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/lead time.pdf' },
        'hp-safety-stock':        { title: 'Safety Stock',                                                 pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/safety stock.pdf' },
        'hp-drug-distribution':   { title: 'Drug Distribution in Hospital',                               pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/drug distribution in hospital.pdf' },
        'hp-individual-prescription': { title: 'Individual Prescription Method',                          pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/individual prescription method.pdf' },
        'hp-floor-stock':         { title: 'Floor Stock Method',                                           pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/floor stock method.pdf' },
        'hp-unit-dose':           { title: 'Unit Dose Drug Distribution Method',                           pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/unit dose drug distribution method.pdf' },
        'hp-narcotics':           { title: 'Distribution of Narcotics and Controlled Substances',          pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/distribution of narcotics and controlled substances.pdf' },
        'hp-cssd':                { title: 'Central Sterile Supply Services — Role of Pharmacist',         pdf: 'pharmd-notes/4th year/hospital pharmacy/hospital pharmacy services/central sterile supply services role of pharmacist.pdf' },

        // ── Manufacture of Pharmaceutical Preparations ────────────────
        'hp-sterile':             { title: 'Sterile Formulations — Large & Small Volume Parenterals',      pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/sterile formulations large and small volume parenterals.pdf' },
        'hp-ointments':           { title: 'Manufacture of Ointments',                                     pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/manufacture of ointments.pdf' },
        'hp-liquids':             { title: 'Manufacture of Liquids',                                       pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/manufacture of liquids.pdf' },
        'hp-creams':              { title: 'Manufacture of Creams',                                        pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/manufacture of creams.pdf' },
        'hp-tablets':             { title: 'Manufacture of Tablets',                                       pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/manufacture of tablets.pdf' },
        'hp-granules':            { title: 'Manufacture of Granules',                                      pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/manufacture of granules.pdf' },
        'hp-capsules':            { title: 'Manufacture of Capsules',                                      pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/manufacture of capsules.pdf' },
        'hp-powders':             { title: 'Manufacture of Powders',                                       pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/manufacture of powders.pdf' },
        'hp-tpn':                 { title: 'Total Parenteral Nutrition (TPN)',                             pdf: 'pharmd-notes/4th year/hospital pharmacy/manufacture of pharmaceutical preparations/total parenteral nutrition.pdf' },

        // ── Continuing Professional Development ───────────────────────
        'hp-education-training':  { title: 'Education and Training',                                       pdf: 'pharmd-notes/4th year/hospital pharmacy/continuing professional development programs/education and training.pdf' },

        // ── Radio Pharmaceuticals ─────────────────────────────────────
        'hp-radio':               { title: 'Radio Pharmaceuticals — Handling and Packaging',               pdf: 'pharmd-notes/4th year/hospital pharmacy/radio pharmaceuticals/radio pharmaceuticals handling and packaging.pdf' },

        // ── Professional Relations & Practices ────────────────────────
        'hp-pro-relations':       { title: 'Professional Relations and Practices of Hospital Pharmacist',  pdf: 'pharmd-notes/4th year/hospital pharmacy/professional relations and practices/professional relations and practices of hospital pharmacist.pdf' },

        // ── Clinical Pharmacy — Unit 1: Basics ───────────────────────────
        'cp-definition':              { title: 'Definition of Clinical Pharmacy',                              pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 1 - basics/definition of clinical pharmacy.pdf' },
        'cp-development':             { title: 'Development of Clinical Pharmacy',                             pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 1 - basics/development of clinical pharmacy.pdf' },
        'cp-scope':                   { title: 'Scope of Clinical Pharmacy',                                   pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 1 - basics/scope of clinical pharmacy.pdf' },

        // ── Clinical Pharmacy — Unit 2: Pharmacist Activities ────────────
        'cp-drug-therapy-monitoring': { title: 'Drug Therapy Monitoring',                                      pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/drug therapy monitoring.pdf' },
        'cp-ward-rounds':             { title: 'Ward Round Participation',                                     pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/ward round participation.pdf' },
        'cp-adr-management':          { title: 'Adverse Drug Reaction (ADR) Management',                      pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/adverse drug reaction management.pdf' },
        'cp-drug-poison-info':        { title: 'Drug and Poison Information Services',                        pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/drug and poison information services.pdf' },
        'cp-medication-history':      { title: 'Medication History',                                           pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/medication history.pdf' },
        'cp-patient-counseling':      { title: 'Patient Counseling',                                           pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/patient counseling.pdf' },
        'cp-due':                     { title: 'Drug Utilization Evaluation (DUE)',                            pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/drug utilization evaluation due.pdf' },
        'cp-dur':                     { title: 'Drug Utilization Review (DUR)',                                pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/drug utilization review dur.pdf' },
        'cp-quality-assurance':       { title: 'Quality Assurance of Clinical Pharmacy Services',             pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 2 - activities/quality assurance of clinical pharmacy services.pdf' },

        // ── Clinical Pharmacy — Unit 3: Patient Data Analysis ────────────
        'cp-case-history':            { title: 'Patient Case History',                                         pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 3 - patient data/patient case history.pdf' },
        'cp-eval-drug-therapy':       { title: 'Evaluation of Drug Therapy',                                  pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 3 - patient data/evaluation of drug therapy.pdf' },
        'cp-abbreviations':           { title: 'Common Medical Abbreviations and Clinical Terminologies',     pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 3 - patient data/common medical abbreviations and clinical terminologies.pdf' },

        // ── Clinical Pharmacy — Unit 4: Lab Tests ────────────────────────
        'cp-lab-interpretation':      { title: 'Interpretation of Lab Results',                               pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/interpretation of lab results.pdf' },
        'cp-haematological-tests':    { title: 'Haematological Tests',                                        pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/haematological tests.pdf' },
        'cp-lft':                     { title: 'Liver Function Tests (LFT)',                                  pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/liver function tests.pdf' },
        'cp-rft':                     { title: 'Renal Function Tests (RFT)',                                  pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/renal function tests.pdf' },
        'cp-thyroid-tests':           { title: 'Thyroid Function Tests',                                      pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/thyroid function tests.pdf' },
        'cp-cardiac-tests':           { title: 'Cardiac-Related Tests',                                       pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/cardiac related tests.pdf' },
        'cp-fluid-electrolytes':      { title: 'Fluid and Electrolyte Balance',                               pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/fluid and electrolyte balance.pdf' },
        'cp-microbiology-culture':    { title: 'Microbiological Culture Sensitivity Tests',                   pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/microbiological culture sensitivity tests.pdf' },
        'cp-pulmonary-tests':         { title: 'Pulmonary Function Tests',                                    pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 4 - lab tests/pulmonary function tests.pdf' },

        // ── Clinical Pharmacy — Unit 5: Drug & Poison Information ────────
        'cp-drug-info-resources':     { title: 'Drug Information Resources',                                  pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 5 - drug and poison info/drug information resources.pdf' },
        'cp-di-systematic-approach':  { title: 'Systematic Approach to Answering Drug Information Queries',  pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 5 - drug and poison info/systematic approach to answering drug information queries.pdf' },
        'cp-di-critical-eval':        { title: 'Critical Evaluation of Drug Literature',                     pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 5 - drug and poison info/critical evaluation of drug literature.pdf' },
        'cp-di-reports':              { title: 'Preparation of Written and Verbal Reports',                   pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 5 - drug and poison info/preparation of written and verbal reports.pdf' },
        'cp-dic-establishment':       { title: 'Establishment of Drug Information Center',                    pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 5 - drug and poison info/establishment of drug information center.pdf' },
        'cp-poison-info':             { title: 'Poison Information and Resources',                            pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 5 - drug and poison info/poison information and resources.pdf' },

        // ── Clinical Pharmacy — Unit 6: Pharmacovigilance ────────────────
        'cp-pv-scope':                { title: 'Scope, Definition and Aims of Pharmacovigilance',             pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 6 - pharmacovigilance/scope definition and aims of pharmacovigilance.pdf' },
        'cp-adr-classification':      { title: 'ADR Classification and Mechanisms',                          pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 6 - pharmacovigilance/adr classification and mechanisms.pdf' },
        'cp-adr-predisposing':        { title: 'Predisposing Factors for ADRs',                              pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 6 - pharmacovigilance/predisposing factors for adrs.pdf' },
        'cp-causality-assessment':    { title: 'Causality Assessment Scales',                                 pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 6 - pharmacovigilance/causality assessment scales.pdf' },
        'cp-adr-reporting':           { title: 'Reporting, Evaluation, Monitoring, Prevention and Management of ADRs', pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 6 - pharmacovigilance/reporting evaluation monitoring prevention and management of adrs.pdf' },
        'cp-pharmacist-adr-role':     { title: 'Role of Pharmacist in ADR Management',                       pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 6 - pharmacovigilance/role of pharmacist in adr management.pdf' },

        // ── Clinical Pharmacy — Unit 7: Communication Skills ─────────────
        'cp-counseling-techniques':   { title: 'Patient Counseling Techniques',                               pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 7 - communication/patient counseling techniques.pdf' },
        'cp-med-history-interview':   { title: 'Medication History Interview',                                pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 7 - communication/medication history interview.pdf' },
        'cp-case-presentation':       { title: 'Case Presentation Skills',                                    pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 7 - communication/case presentation skills.pdf' },

        // ── Clinical Pharmacy — Unit 8: Pharmaceutical Care ──────────────
        'cp-pharm-care-concepts':     { title: 'Concepts of Pharmaceutical Care',                             pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 8 - pharmaceutical care/concepts of pharmaceutical care.pdf' },

        // ── Clinical Pharmacy — Unit 9: Medication Errors ────────────────
        'cp-med-error-types':         { title: 'Types of Medication Errors',                                  pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 9 - medication errors/types of medication errors.pdf' },
        'cp-med-error-prevention':    { title: 'Prevention and Management of Medication Errors',              pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 9 - medication errors/prevention and management of medication errors.pdf' },

        // ── Clinical Pharmacy — Unit 10: Biomedical Literature Evaluation ─
        'cp-biomedical-lit-eval':     { title: 'Critical Evaluation of Biomedical Literature',                pdf: 'pharmd-notes/4th year/clinical pharmacy/unit 10 - literature evaluation/critical evaluation of biomedical literature.pdf' },

        // ── Biostatistics & Research Methodology — Unit 1: Research Methodology ─
        'bs-study-designs':              { title: 'Study Designs and Methodology Design',                          pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 1 - research methodology/study designs and methodology design.pdf' },
        'bs-sample-size':                { title: 'Sample Size Determination and Power of Study',                  pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 1 - research methodology/sample size determination and power of study.pdf' },
        'bs-data-presentation':          { title: 'Data Presentation, Report Writing and Interpretation',          pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 1 - research methodology/data presentation report writing and interpretation.pdf' },

        // ── Biostatistics & Research Methodology — Unit 2: Biostatistics ──
        'bs-intro-distributions':        { title: 'Introduction and Data Distributions',                           pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 2 - biostatistics/introduction and data distributions.pdf' },
        'bs-central-tendency':           { title: 'Central Tendency — Mean, Median, Mode',                        pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 2 - biostatistics/central tendency mean median mode.pdf' },
        'bs-dispersion':                 { title: 'Dispersion — Range, Variance, SD, CV, SE',                     pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 2 - biostatistics/dispersion range variance standard deviation coefficient of variation standard error.pdf' },

        // ── Biostatistics & Research Methodology — Unit 3: Data Graphics ──
        'bs-graph-construction':         { title: 'Graph Construction and Labeling',                               pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 3 - data graphics/graph construction and labeling histogram pie chart scatter plot semilog plots.pdf' },

        // ── Biostatistics & Research Methodology — Unit 4: Hypothesis Testing
        'bs-hypothesis-testing':         { title: 'Hypothesis Testing',                                            pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 4 - hypothesis testing and statistics/hypothesis testing null hypothesis p-value significance power confidence intervals.pdf' },
        'bs-parametric-tests':           { title: 'Parametric Tests — t-test, Chi-square, ANOVA',                 pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 4 - hypothesis testing and statistics/parametric tests t-test chi-square anova.pdf' },
        'bs-nonparametric-tests':        { title: 'Non-Parametric Tests',                                         pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 4 - hypothesis testing and statistics/non-parametric tests sign test wilcoxon tests mann-whitney kruskal-wallis.pdf' },
        'bs-regression-correlation':     { title: 'Regression and Correlation — Pearson, Spearman',               pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 4 - hypothesis testing and statistics/regression and correlation pearson spearman.pdf' },
        'bs-statistical-software':       { title: 'Statistical Software — SPSS, Epi Info, SAS',                   pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 4 - hypothesis testing and statistics/statistical software spss epi info sas.pdf' },

        // ── Biostatistics & Research Methodology — Unit 5: Epidemiology ───
        'bs-epidemiology':               { title: 'Incidence, Prevalence, Relative Risk and Attributable Risk',   pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 5 - epidemiology/incidence prevalence relative risk attributable risk.pdf' },

        // ── Biostatistics & Research Methodology — Unit 6: Computer Apps ──
        'bs-hospital-pharmacy-systems':  { title: 'Hospital Pharmacy Systems',                                     pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 6 - computer applications in pharmacy/hospital pharmacy systems records order entry iv admixture inventory reports.pdf' },
        'bs-community-pharmacy-systems': { title: 'Community Pharmacy Systems',                                    pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 6 - computer applications in pharmacy/community pharmacy systems dispensing pharmaceutical care accounting.pdf' },
        'bs-drug-info-systems':          { title: 'Drug Information Systems',                                      pdf: 'pharmd-notes/4th year/biostatistics and research methodology/unit 6 - computer applications in pharmacy/drug information systems retrieval storage literature search.pdf' },

        // ── Biopharmaceutics & Pharmacokinetics — Unit 1: Basics ─────────
        'bp-intro-biopharmaceutics':    { title: 'Introduction to Biopharmaceutics',                              pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 1 - biopharmaceutics basics/introduction to biopharmaceutics.pdf' },
        'bp-absorption-gi':             { title: 'Absorption of Drugs from Gastrointestinal Tract',               pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 1 - biopharmaceutics basics/absorption of drugs from gastrointestinal tract.pdf' },
        'bp-drug-distribution':         { title: 'Drug Distribution',                                             pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 1 - biopharmaceutics basics/drug distribution.pdf' },
        'bp-drug-elimination':          { title: 'Drug Elimination',                                              pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 1 - biopharmaceutics basics/drug elimination.pdf' },

        // ── Biopharmaceutics & Pharmacokinetics — Unit 2: PK Fundamentals ─
        'bp-intro-pk':                  { title: 'Introduction to Pharmacokinetics',                              pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 2 - pharmacokinetics fundamentals/introduction to pharmacokinetics.pdf' },
        'bp-mathematical-model':        { title: 'Mathematical Model',                                            pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 2 - pharmacokinetics fundamentals/mathematical model.pdf' },
        'bp-drug-levels-blood':         { title: 'Drug Levels in Blood',                                          pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 2 - pharmacokinetics fundamentals/drug levels in blood.pdf' },
        'bp-pk-models':                 { title: 'Pharmacokinetic Models',                                        pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 2 - pharmacokinetics fundamentals/pharmacokinetic models.pdf' },
        'bp-compartment-models':        { title: 'Compartment Models',                                            pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 2 - pharmacokinetics fundamentals/compartment models.pdf' },
        'bp-pk-study':                  { title: 'Pharmacokinetic Study',                                         pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 2 - pharmacokinetics fundamentals/pharmacokinetic study.pdf' },

        // ── Biopharmaceutics & Pharmacokinetics — Unit 3: One Compartment ─
        'bp-one-compartment-open':      { title: 'One Compartment Open Model',                                    pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 3 - one compartment model/one compartment open model.pdf' },
        'bp-iv-injection':              { title: 'Intravenous Injection',                                         pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 3 - one compartment model/intravenous injection.pdf' },
        'bp-iv-infusion':               { title: 'Intravenous Infusion',                                          pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 3 - one compartment model/intravenous infusion.pdf' },

        // ── Biopharmaceutics & Pharmacokinetics — Unit 4: Multicompartment ─
        'bp-multicompartment-models':   { title: 'Multicompartment Models',                                       pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 4 - multicompartment models/multicompartment models.pdf' },
        'bp-two-compartment-open':      { title: 'Two Compartment Open Model',                                    pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 4 - multicompartment models/two compartment open model.pdf' },
        'bp-mc-iv-bolus':               { title: 'IV Bolus',                                                      pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 4 - multicompartment models/iv bolus.pdf' },
        'bp-mc-iv-infusion':            { title: 'IV Infusion',                                                    pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 4 - multicompartment models/iv infusion.pdf' },
        'bp-mc-oral':                   { title: 'Oral Administration',                                           pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 4 - multicompartment models/oral administration.pdf' },

        // ── Biopharmaceutics & Pharmacokinetics — Unit 5: Dosage Regimens ─
        'bp-multiple-dosage-regimens':  { title: 'Multiple Dosage Regimens',                                      pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 5 - dosage regimens/multiple dosage regimens.pdf' },
        'bp-repetitive-iv-injections':  { title: 'Repetitive Intravenous Injections',                             pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 5 - dosage regimens/repetitive intravenous injections.pdf' },
        'bp-one-comp-extravascular':    { title: 'One Compartment Open Model — Repetitive Extravascular Dosing',  pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 5 - dosage regimens/one compartment open model repetitive extravascular dosing.pdf' },
        'bp-one-comp-multiple-dose':    { title: 'One Compartment Open Model — Multiple Dose Regimen',            pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 5 - dosage regimens/one compartment open model multiple dose regimen.pdf' },
        'bp-two-comp-multiple-dose':    { title: 'Two Compartment Open Model',                                    pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 5 - dosage regimens/two compartment open model.pdf' },

        // ── Biopharmaceutics & Pharmacokinetics — Unit 6: Nonlinear PK ───
        'bp-nonlinear-pk-intro':        { title: 'Nonlinear Pharmacokinetics Introduction',                       pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 6 - nonlinear pharmacokinetics/nonlinear pharmacokinetics introduction.pdf' },
        'bp-nonlinearity-factors':      { title: 'Factors Causing Non-Linearity',                                 pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 6 - nonlinear pharmacokinetics/factors causing non-linearity.pdf' },
        'bp-michaelis-menten':          { title: 'Michaelis-Menten Method of Estimating Parameters',              pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 6 - nonlinear pharmacokinetics/michaelis-menten method of estimating parameters.pdf' },

        // ── Biopharmaceutics & Pharmacokinetics — Unit 7: Noncompartmental ─
        'bp-statistical-moment':        { title: 'Statistical Moment Theory',                                     pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 7 - noncompartmental pharmacokinetics/statistical moment theory.pdf' },
        'bp-mrt':                       { title: 'Mean Residence Time (MRT) for Various Compartment Models',      pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 7 - noncompartmental pharmacokinetics/mean residence time mrt for various compartment models.pdf' },
        'bp-physiological-pk-model':    { title: 'Physiological Pharmacokinetic Model',                           pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 7 - noncompartmental pharmacokinetics/physiological pharmacokinetic model.pdf' },

        // ── Biopharmaceutics & Pharmacokinetics — Unit 8: Bioavailability ─
        'bp-intro-bioavailability':     { title: 'Introduction to Bioavailability and Bioequivalence',            pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 8 - bioavailability and bioequivalence/introduction to bioavailability and bioequivalence.pdf' },
        'bp-bioavailability-protocol':  { title: 'Bioavailability Study Protocol',                                pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 8 - bioavailability and bioequivalence/bioavailability study protocol.pdf' },
        'bp-bioavailability-assessment':{ title: 'Methods of Assessment of Bioavailability',                      pdf: 'pharmd-notes/4th year/biopharmaceutics and pharmacokinetics/unit 8 - bioavailability and bioequivalence/methods of assessment of bioavailability.pdf' },

        // ── Clinical Toxicology — Unit 1: General Principles ─────────────
        'ct-general-principles':           { title: 'General Principles Involved in the Management of Poisoning', pdf: 'pharmd-notes/4th year/clinical toxicology/unit 1 - general principles of poisoning/general principles involved in the management of poisoning.pdf' },
        'ct-intro-clinical-tox':           { title: 'Introduction of Clinical Toxicology',                        pdf: 'pharmd-notes/4th year/clinical toxicology/unit 1 - general principles of poisoning/introduction of clinical toxicology.pdf' },
        'ct-management-general':           { title: 'Management of Poisoning (General Principles)',               pdf: 'pharmd-notes/4th year/clinical toxicology/unit 1 - general principles of poisoning/management of poisoning general principles.pdf' },

        // ── Clinical Toxicology — Unit 2: Antidotes ──────────────────────
        'ct-antidotes-clinical':           { title: 'Antidotes and Their Clinical Applications',                  pdf: 'pharmd-notes/4th year/clinical toxicology/unit 2 - antidotes/antidotes and their clinical applications.pdf' },
        'ct-nac-atropine-mesna':           { title: 'N-Acetyl Cysteine, Atropine, Mesna etc.',                   pdf: 'pharmd-notes/4th year/clinical toxicology/unit 2 - antidotes/n-acetyl cysteine atropine mesna etc.pdf' },

        // ── Clinical Toxicology — Unit 3: Supportive Care ────────────────
        'ct-supportive-care':              { title: 'Supportive Care in Clinical Toxicology',                     pdf: 'pharmd-notes/4th year/clinical toxicology/unit 3 - supportive care/supportive care in clinical toxicology.pdf' },
        'ct-abc':                          { title: 'Airway, Breathing, Circulation (ABC)',                       pdf: 'pharmd-notes/4th year/clinical toxicology/unit 3 - supportive care/airway breathing circulation abc.pdf' },

        // ── Clinical Toxicology — Unit 4: Gut Decontamination ────────────
        'ct-gut-decontamination-methods':  { title: 'Methods of Gut Decontamination',                             pdf: 'pharmd-notes/4th year/clinical toxicology/unit 4 - gut decontamination/methods of gut decontamination.pdf' },
        'ct-decontamination-agents':       { title: 'Use of Different Agents During Decontamination',             pdf: 'pharmd-notes/4th year/clinical toxicology/unit 4 - gut decontamination/use of different agents during decontamination.pdf' },

        // ── Clinical Toxicology — Unit 5: Elimination Enhancement ────────
        'ct-elimination-methods':          { title: 'Methods of Elimination Enhancement',                         pdf: 'pharmd-notes/4th year/clinical toxicology/unit 5 - elimination enhancement/methods of elimination enhancement.pdf' },
        'ct-elimination-agents':           { title: 'Agents Used During Elimination Enhancement',                 pdf: 'pharmd-notes/4th year/clinical toxicology/unit 5 - elimination enhancement/agents used during elimination enhancement.pdf' },

        // ── Clinical Toxicology — Unit 6: Toxicokinetics ─────────────────
        'ct-toxicokinetics-adme':          { title: 'Absorption, Distribution, Metabolism, Elimination of Toxins', pdf: 'pharmd-notes/4th year/clinical toxicology/unit 6 - toxicokinetics/absorption distribution metabolism elimination of toxins.pdf' },
        'ct-toxicokinetics-factors':       { title: 'Factors Affecting Toxicokinetics',                           pdf: 'pharmd-notes/4th year/clinical toxicology/unit 6 - toxicokinetics/factors affecting toxicokinetics.pdf' },

        // ── Clinical Toxicology — Unit 7: Acute Poisoning ────────────────
        'ct-acute-poisoning-general':      { title: 'Clinical Symptoms and Management of Acute Poisoning',        pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/clinical symptoms and management of acute poisoning.pdf' },
        'ct-pesticide-poisoning':          { title: 'Pesticide Poisoning',                                        pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/pesticide poisoning organophosphorus carbamates organochlorines pyrethroids.pdf' },
        'ct-opiates-overdose':             { title: 'Opiates Overdose',                                           pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/opiates overdose.pdf' },
        'ct-antidepressants-poisoning':    { title: 'Antidepressants',                                            pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/antidepressants.pdf' },
        'ct-barbiturates-benzodiazepines': { title: 'Barbiturates and Benzodiazepines',                           pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/barbiturates and benzodiazepines.pdf' },
        'ct-alcohols':                     { title: 'Alcohols — Ethanol and Methanol',                            pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/alcohols ethanol methanol.pdf' },
        'ct-paracetamol-salicylates':      { title: 'Paracetamol and Salicylates',                                pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/paracetamol and salicylates.pdf' },
        'ct-nsaids-poisoning':             { title: 'NSAIDs',                                                     pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/nsaids.pdf' },
        'ct-hydrocarbons':                 { title: 'Hydrocarbons — Petroleum Products and PEG',                  pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/hydrocarbons petroleum products peg.pdf' },
        'ct-caustics':                     { title: 'Caustics — Inorganic Acids and Alkali',                      pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/caustics inorganic acids and alkali.pdf' },
        'ct-radiation-poisoning':          { title: 'Radiation Poisoning',                                        pdf: 'pharmd-notes/4th year/clinical toxicology/unit 7 - acute poisoning management/radiation poisoning.pdf' },

        // ── Clinical Toxicology — Unit 8: Chronic Poisoning ──────────────
        'ct-chronic-poisoning-general':    { title: 'Clinical Symptoms and Management of Chronic Poisoning',      pdf: 'pharmd-notes/4th year/clinical toxicology/unit 8 - chronic poisoning/clinical symptoms and management of chronic poisoning.pdf' },
        'ct-heavy-metals':                 { title: 'Heavy Metals — Arsenic, Lead, Mercury, Iron, Copper',        pdf: 'pharmd-notes/4th year/clinical toxicology/unit 8 - chronic poisoning/heavy metals arsenic lead mercury iron copper.pdf' },

        // ── Clinical Toxicology — Unit 9: Snake Bite ─────────────────────
        'ct-venomous-snake-bites':         { title: 'Venomous Snake Bites',                                       pdf: 'pharmd-notes/4th year/clinical toxicology/unit 9 - snake bite/venomous snake bites.pdf' },
        'ct-snake-families':               { title: 'Families of Venomous Snakes',                                pdf: 'pharmd-notes/4th year/clinical toxicology/unit 9 - snake bite/families of venomous snakes.pdf' },
        'ct-venom-effects':                { title: 'Clinical Effects of Venom',                                  pdf: 'pharmd-notes/4th year/clinical toxicology/unit 9 - snake bite/clinical effects of venom.pdf' },
        'ct-snakebite-management':         { title: 'General Management, First Aid and Complications',            pdf: 'pharmd-notes/4th year/clinical toxicology/unit 9 - snake bite/general management first aid complications.pdf' },

        // ── Clinical Toxicology — Unit 10: Plant Poisoning ───────────────
        'ct-mushroom-poisoning':           { title: 'Mushroom Poisoning',                                         pdf: 'pharmd-notes/4th year/clinical toxicology/unit 10 - plant poisoning/mushroom poisoning.pdf' },
        'ct-mycotoxins':                   { title: 'Mycotoxins',                                                 pdf: 'pharmd-notes/4th year/clinical toxicology/unit 10 - plant poisoning/mycotoxins.pdf' },

        // ── Clinical Toxicology — Unit 11: Food Poisoning ────────────────
        'ct-food-poisoning-types':         { title: 'Types of Food Poisoning',                                    pdf: 'pharmd-notes/4th year/clinical toxicology/unit 11 - food poisoning/types of food poisoning.pdf' },
        'ct-food-poisoning-organisms':     { title: 'Organisms Involved and Management',                          pdf: 'pharmd-notes/4th year/clinical toxicology/unit 11 - food poisoning/organisms involved and management.pdf' },

        // ── Clinical Toxicology — Unit 12: Envenomation ──────────────────
        'ct-envenomation-principles':      { title: 'General Principles of Envenomation',                         pdf: 'pharmd-notes/4th year/clinical toxicology/unit 12 - envenomation/general principles of envenomation.pdf' },
        'ct-arthropod-bites':              { title: 'Arthropod Bites and Stings',                                 pdf: 'pharmd-notes/4th year/clinical toxicology/unit 12 - envenomation/arthropod bites and stings.pdf' },

        '_end': null  // sentinel — do not remove
    };

    // ── 1st Year subject photos — loaded from Google Drive ──────────────
    // Fill in each subject's Google Drive file ID below (the long ID from
    // a "share" link like https://drive.google.com/file/d/FILE_ID/view).
    // Leave blank to show just the subject name (no photo, no placeholder box).
    var LN_YEAR1_PHOTOS = {
        'lnHAP':            '1qtxPzNcgbnkZ76fdPipNOpyBwFh0vfKO',   // Human Anatomy and Physiology
        'lnPharmaceutics':  '16HXYFNX31NUHNVS08C9YyKxLXvmPSEdv',   // Pharmaceutics
        'lnMedBiochem':     '1PelVEjFYbgvh20YKmSg95EFOI351cKw2',   // Medicinal Biochemistry
        'lnPharmOrgChem':   '1gHSpePwjxqcaCPa8E4YUOuFZTUf0v5Lt',   // Pharmaceutical Organic Chemistry
        'lnPharmInorgChem': '1Ci3A_IkfvYIZJKUyHOPsNMrxM_T8O4gT',   // Pharmaceutical Inorganic Chemistry
        'lnRemedialMath':   '18UTL-inwREOQ1-H3XL8WEB2CFZXmR20h'    // Remedial Mathematics / Biology
    };

    // ── 2nd Year subject photos — same pattern as Year 1 above ──────────
    var LN_YEAR2_PHOTOS = {
        'lnPathophysiology':      '',   // Pathophysiology
        'lnPharmMicrobiology':    '',   // Pharmaceutical Microbiology
        'lnPharmacognosy':        '',   // Pharmacognosy & Phytopharmaceuticals
        'lnPharmacologyI':        '',   // Pharmacology-I
        'lnCommunityPharmacy':    '',   // Community Pharmacy
        'lnPharmacotherapeuticsI':''    // Pharmacotherapeutics-I
    };

    function _lnDrivePhotoUrls(fileId) {
        // Try multiple Drive-serving formats in order, since different
        // files/accounts behave differently with each endpoint. If one
        // fails to load, the next is tried automatically before we give
        // up (the image is simply left hidden — no placeholder box).
        var id = encodeURIComponent(fileId);
        return [
            'https://lh3.googleusercontent.com/d/' + id + '=w1000',
            'https://drive.google.com/thumbnail?id=' + id + '&sz=w1000',
            'https://drive.google.com/uc?export=view&id=' + id
        ];
    }

    // Generic loader — works for any {subjectId: fileId} map, so the same
    // logic (multi-format fallback + auto-retry) applies to every year.
    function lnLoadSubjectPhotos(photoMap) {
        Object.keys(photoMap).forEach(function(subjectId) {
            var fileId = photoMap[subjectId];
            var img = document.getElementById('photo-' + subjectId);
            if (!img || !fileId) return; // no Drive ID yet — card shows just the name

            var urls = _lnDrivePhotoUrls(fileId);
            var attempt = 0;
            // A newly-shared Drive file can take a little while for Google's
            // CDN to generate a public thumbnail. Rather than give up after
            // one pass, retry the whole URL list a few times with a delay —
            // if the photo becomes available while the page is still open,
            // it'll just quietly appear on its own, no reload needed.
            var retryRound = 0;
            var maxRetryRounds = 6;       // ~6 retry passes
            var retryDelayMs = 8000;      // 8s between passes (~48s total)

            function tryNext() {
                if (attempt >= urls.length) {
                    if (retryRound < maxRetryRounds) {
                        retryRound++;
                        attempt = 0;
                        setTimeout(tryNext, retryDelayMs);
                    } else {
                        // Genuinely exhausted — image stays hidden, no placeholder.
                        img.style.display = 'none';
                    }
                    return;
                }
                img.src = urls[attempt];
                attempt++;
            }

            img.onload = function() {
                img.style.display = 'block';
            };
            img.onerror = tryNext;

            tryNext();
        });
    }

    function lnLoadYear1Photos() {
        lnLoadSubjectPhotos(LN_YEAR1_PHOTOS);
        lnLoadSubjectPhotos(LN_YEAR2_PHOTOS);
    }

    // Load once on page load, and again each time the 1st Year subjects
    // page is shown (in case photo IDs were updated at runtime).
    document.addEventListener('DOMContentLoaded', lnLoadYear1Photos);

    function lnYearClick(year) {
        if (year === 4) { showPage('lnYear4'); }
        else { appState.showNotification('Year ' + year + ' notes are coming soon!', 'success'); }
    }

    function lnComingSoon() {
        appState.showNotification('This subject is coming soon!', 'success');
    }

    // ── PDF.js state ──────────────────────────────────────────────────
    var _lnPdfDoc     = null;
    var _lnRendered   = {};
    var _lnScrollObs  = null;
    var _lnTotalPages = 0;
    var _lnPdfjsReady = false;
    var _lnDpr        = window.devicePixelRatio || 1;

    function _lnPageW() {
        var el = document.getElementById('lnPdfBody');
        var w  = (el && el.clientWidth) || window.innerWidth || 360;
        return w - 8; // fill (almost) the full width of the viewer, edge-to-edge
    }

    // Preload PDF.js on page load so it's ready when user taps
    (function() {
        if (typeof pdfjsLib !== 'undefined') { _lnPdfjsReady = true; return; }
        var s = document.createElement('script');
        s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
        s.onload = function() {
            pdfjsLib.GlobalWorkerOptions.workerSrc =
                'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
            _lnPdfjsReady = true;
        };
        document.head.appendChild(s);
    })();

    function lnOpenPdf(topicId) {
        var topic = LN_PDF_MAP[topicId];
        if (!topic) return;

        var base = window.location.origin + window.location.pathname.replace(/\/[^/]*$/, '/');
        var url  = base + topic.pdf.split('/').map(encodeURIComponent).join('/');

        // Show modal
        var modal = document.getElementById('lnPdfModal');
        var sheet = document.getElementById('lnPdfSheet');
        modal.style.display = 'flex';
        requestAnimationFrame(function() {
            requestAnimationFrame(function() { sheet.style.transform = 'translateY(0)'; });
        });

        document.getElementById('lnPdfTitle').textContent = topic.title;
        document.getElementById('lnPageCounter').textContent = 'Loading…';
        document.getElementById('lnProgressBar').style.width = '0%';

        var body = document.getElementById('lnPdfBody');
        body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:200px;gap:0.75rem;">'
            + '<div style="width:24px;height:24px;border:3px solid rgba(14,165,233,0.3);border-top-color:#0ea5e9;border-radius:50%;animation:spin 0.8s linear infinite;"></div>'
            + '<span style="color:#475569;font-size:0.8rem;">Loading PDF…</span></div>';

        _lnRendered   = {};
        _lnTotalPages = 0;

        // Android back button — handled by main popstate via _closeTopOverlay
        history.pushState({ lnPdf: true }, '');

        var go = function() {
            var task = pdfjsLib.getDocument({ url: url });
            task.onProgress = function(d) {
                if (d.total) document.getElementById('lnProgressBar').style.width = Math.round(d.loaded / d.total * 85) + '%';
            };
            task.promise.then(function(pdf) {
                _lnPdfDoc     = pdf;
                _lnTotalPages = pdf.numPages;
                document.getElementById('lnPageCounter').textContent = pdf.numPages + ' pages';
                document.getElementById('lnProgressBar').style.width = '100%';
                setTimeout(function() { document.getElementById('lnProgressBar').style.opacity = '0'; }, 500);

                body.innerHTML = '';
                var container = document.createElement('div');
                container.style.cssText = 'padding:10px 0 20px;';
                body.appendChild(container);

                // Placeholders for all pages
                for (var i = 1; i <= pdf.numPages; i++) {
                    var wrap = document.createElement('div');
                    wrap.className = 'ln-pg';
                    wrap.setAttribute('data-page', i);
                    wrap.style.cssText = 'margin:6px auto;width:' + _lnPageW() + 'px;'
                        + 'min-height:' + Math.round(_lnPageW() * 1.414) + 'px;'
                        + 'background:#262830;border-radius:6px;display:flex;align-items:center;justify-content:center;';
                    wrap.innerHTML = '<span style="color:#2d3748;font-size:0.65rem;letter-spacing:0.08em;">PAGE ' + i + '</span>';
                    container.appendChild(wrap);
                }

                // Lazy render only visible pages
                if (_lnScrollObs) _lnScrollObs.disconnect();
                _lnScrollObs = new IntersectionObserver(function(entries) {
                    entries.forEach(function(e) {
                        if (e.isIntersecting) {
                            var n = parseInt(e.target.getAttribute('data-page'));
                            if (!_lnRendered[n]) _lnRenderPage(n, e.target);
                        }
                    });
                }, { root: body, rootMargin: '400px', threshold: 0 });
                container.querySelectorAll('.ln-pg').forEach(function(el) { _lnScrollObs.observe(el); });

                // Scroll = update progress
                body.addEventListener('scroll', function() {
                    var pgs = body.querySelectorAll('.ln-pg');
                    var mid = body.scrollTop + body.clientHeight / 2;
                    var cur = 1;
                    pgs.forEach(function(p) { if (p.offsetTop <= mid) cur = parseInt(p.getAttribute('data-page')); });
                    var bar = document.getElementById('lnProgressBar');
                    bar.style.opacity = '1';
                    bar.style.width = Math.round(cur / _lnTotalPages * 100) + '%';
                }, { passive: true });

            }).catch(function() {
                body.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:1rem;padding:2rem;">'
                    + '<div style="font-size:2.5rem;"></div>'
                    + '<p style="color:#94a3b8;font-size:0.8rem;text-align:center;">Could not load PDF.<br>Check the file exists in your repo.</p>'
                    + '<p style="color:#475569;font-size:0.7rem;word-break:break-all;text-align:center;">' + url + '</p></div>';
            });
        };

        if (_lnPdfjsReady) { go(); }
        else {
            var waited = 0;
            var poll = setInterval(function() {
                if (_lnPdfjsReady) { clearInterval(poll); go(); }
                else if ((waited += 100) > 8000) { clearInterval(poll); }
            }, 100);
        }
    }

    function _lnRenderPage(num, wrap) {
        if (_lnRendered[num] || !_lnPdfDoc) return;
        _lnRendered[num] = true;
        _lnPdfDoc.getPage(num).then(function(page) {
            var vp     = page.getViewport({ scale: 3.2 * _lnDpr });
            var canvas = document.createElement('canvas');
            var ctx    = canvas.getContext('2d');
            canvas.width  = vp.width;
            canvas.height = vp.height;
            canvas.style.cssText = 'display:block;width:100%;height:auto;opacity:0;transition:opacity 0.3s;';
            wrap.innerHTML = '';
            wrap.style.cssText = 'margin:6px auto;width:' + _lnPageW() + 'px;'
                + 'background:#fff;border-radius:6px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.5);min-height:unset;';
            wrap.appendChild(canvas);
            page.render({ canvasContext: ctx, viewport: vp }).promise.then(function() {
                requestAnimationFrame(function() { canvas.style.opacity = '1'; });
            });
        });
    }

    function closeLnPdf() {
        var sheet = document.getElementById('lnPdfSheet');
        var modal = document.getElementById('lnPdfModal');
        sheet.style.transform = 'translateY(100%)';
        setTimeout(function() {
            modal.style.display = 'none';
            document.getElementById('lnPdfBody').innerHTML = '';
            var bar = document.getElementById('lnProgressBar');
            bar.style.width = '0%'; bar.style.opacity = '1';
        }, 400);
        if (_lnScrollObs) { _lnScrollObs.disconnect(); _lnScrollObs = null; }
        _lnPdfDoc = null; _lnRendered = {};
    }


    
