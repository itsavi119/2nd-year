    // ══════════════════════════════════════════════════════════════
    // BOTTOM TAB BAR — Home / Subjects / Saved / Profile
    // This file (pharmd-notes.html) is a linked branch of the main
    // app (index.html). "Subjects" and "Saved" stay local — Subjects
    // is this file's own "Select Year" entry page (lecturerNotes),
    // and Saved is the local bookmarks list (lnSaved) built from the
    // bookmark-icon button on every subject/unit/topic page. "Home" and "Profile"
    // don't have an equivalent here, so they route back to the main
    // app's matching page/feature.
    // ══════════════════════════════════════════════════════════════
    function bnSetActive(tab) {
        ['Home', 'Subjects', 'Saved', 'Profile'].forEach(function (label) {
            var el = document.getElementById('bn' + label);
            if (!el) return;
            var isNowActive = label.toLowerCase() === tab;
            var justActivated = isNowActive && !el.classList.contains('active');
            el.classList.toggle('active', isNowActive);
            if (justActivated) {
                el.classList.remove('mi-pop');
                void el.offsetWidth; // restart the keyframe animation if re-triggered quickly
                el.classList.add('mi-pop');
                setTimeout(function () { el.classList.remove('mi-pop'); }, 400);
            }
        });
    }

    function bnGo(tab) {
        if (tab === 'subjects') {
            // Stay in this file — go to the local "Select Year" page.
            showPage('lecturerNotes');
            bnSetActive('subjects');
        } else if (tab === 'saved') {
            // Stay in this file — go to the local bookmarks list.
            lnRenderSavedList();
            showPage('lnSaved');
            bnSetActive('saved');
        } else if (tab === 'home') {
            window.location.href = 'index.html';
        } else if (tab === 'profile') {
            window.location.href = 'index.html#profile';
        }
    }

    // ── Auto-hide on inactivity (touch/mobile layout only) ───────────
    // Desktop/mouse users keep the nav always visible — this only runs
    // on coarse-pointer (touch) devices, matching the mobile layout in
    // the reference design. Any tap anywhere shows the nav and resets
    // a 2.5s timer; no further taps within that window hides it again.
    // The nav's own position/size/design are untouched — only the CSS
    // transform/opacity from the .bn-hidden class (see .bottom-nav
    // above) toggles for its own hide animation. Alongside that, an
    // html.bn-collapsed class collapses the --bn-space variable that
    // every .page reads for its bottom inset (see :root and .page
    // above), so the space reserved for the nav closes up with it
    // instead of leaving a blank gap once the nav is gone. Taps on
    // chapter cards / scrolling are unaffected since this only listens
    // (passively) — it never calls preventDefault or stopPropagation.
    (function bnAutoHideInit() {
        var nav = document.getElementById('bottomNav');
        if (!nav) return;
        if (!window.matchMedia || !window.matchMedia('(hover: none) and (pointer: coarse)').matches) {
            return; // not a touch device — leave the nav always visible
        }

        var HIDE_DELAY_MS = 2500;
        var hideTimer = null;

        function showNav() {
            nav.classList.remove('bn-hidden');
            document.documentElement.classList.remove('bn-collapsed');
        }

        function scheduleHide() {
            if (hideTimer) clearTimeout(hideTimer);
            hideTimer = setTimeout(function () {
                nav.classList.add('bn-hidden');
                document.documentElement.classList.add('bn-collapsed');
            }, HIDE_DELAY_MS);
        }

        function onActivity() {
            showNav();
            scheduleHide();
        }

        document.addEventListener('pointerdown', onActivity, { passive: true });
        scheduleHide(); // start hidden-after-inactivity from page load too
    })();
    
