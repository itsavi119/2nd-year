                (function () {
                    function pmicInit() {
                        var page = document.getElementById('lnPharmMicrobiology');
                        var scrollEl = document.getElementById('pmicScroll');
                        var hero = page ? page.querySelector('.pmic-hero') : null;
                        var spacer = document.getElementById('pmicHeroSpacer');
                        var tabbar = document.getElementById('pmicTabbar');
                        var chaptersSection = document.getElementById('pmicChaptersSection');
                        var tabOverview = document.getElementById('pmicTabOverview');
                        var tabChapters = document.getElementById('pmicTabChapters');
                        if (!page || !scrollEl || !hero || !spacer || !tabbar || !chaptersSection || !tabOverview || !tabChapters) return;
                        if (page._pmicInitDone) return;
                        page._pmicInitDone = true;

                        // Remember the tab bar's original spot in the
                        // DOM (inside the scrollable container, right
                        // before the content card) so it can be moved
                        // back there for portrait. See
                        // pmicSyncTabbarPosition() below for why it
                        // sometimes gets moved out of that container.
                        var pmicTabbarHomeParent = tabbar.parentNode;
                        var pmicTabbarHomeNextSibling = tabbar.nextSibling;

                        var PMIC_PEEK_PX = 4.35 * parseFloat(getComputedStyle(document.documentElement).fontSize || 16);

                        function syncHeroHeight() {
                            spacer.style.height = Math.max(0, hero.offsetHeight - PMIC_PEEK_PX) + 'px';
                        }
                        syncHeroHeight();

                        // Landscape only: keep the Overview/Chapters bar
                        // pinned near the hero's bottom edge instead of
                        // letting it sit in the scrollable content below,
                        // where a tall landscape hero could push it off the
                        // visible screen. Uses the hero's actual rendered
                        // height (already tracked above) so it stays
                        // correctly placed across screen sizes.
                        var pmicAnyLandscapeMql = window.matchMedia('(min-width: 999999px)'); // disabled: tabbar now always stays in normal sticky flow, matching mobile-view behavior, instead of being pinned/fixed near the hero in landscape.
                        function pmicSyncTabbarPosition() {
                            if (pmicAnyLandscapeMql.matches) {
                                // Move the tab bar out of the scrollable
                                // container entirely first. Nested inside
                                // an element with -webkit-overflow-scrolling:
                                // touch, position:fixed isn't reliable across
                                // mobile browsers — it can scroll away or
                                // drop behind other content instead of
                                // staying put. As a direct sibling of the
                                // hero (outside that scrolling container) it
                                // has no such ancestor, so "fixed" behaves
                                // as expected.
                                if (tabbar.parentNode !== page) {
                                    page.insertBefore(tabbar, scrollEl);
                                }
                                tabbar.style.top = Math.max(0, hero.offsetHeight - PMIC_PEEK_PX) + 'px';
                            } else {
                                if (tabbar.parentNode !== pmicTabbarHomeParent) {
                                    pmicTabbarHomeParent.insertBefore(tabbar, pmicTabbarHomeNextSibling);
                                }
                                tabbar.style.top = '';
                            }
                        }
                        pmicSyncTabbarPosition();

                        var STUCK_ON  = 16.5;
                        var STUCK_OFF = 16.5 + 8; // hysteresis buffer so it doesn't flicker right at the edge
                        var isStuck = false;

                        function updateStuck() {
                            if (scrollEl.scrollTop <= 2) {
                                isStuck = false;
                            } else {
                                var gap = tabbar.getBoundingClientRect().top - scrollEl.getBoundingClientRect().top;
                                if (!isStuck && gap <= STUCK_ON) isStuck = true;
                                else if (isStuck && gap > STUCK_OFF) isStuck = false;
                            }
                            tabbar.classList.toggle('is-stuck', isStuck);
                            page.classList.toggle('pmic-stuck', isStuck);
                        }

                        function setActive(which) {
                            if (which === 'chapters') {
                                tabChapters.classList.add('active');
                                tabOverview.classList.remove('active');
                            } else {
                                tabOverview.classList.add('active');
                                tabChapters.classList.remove('active');
                            }
                        }

                        function chaptersIsActive() {
                            var scrollRect = scrollEl.getBoundingClientRect();
                            var chapRect = chaptersSection.getBoundingClientRect();
                            return (chapRect.top - scrollRect.top) <= 90;
                        }

                        
                        // Desktop + landscape only: when this page opens, glide
                        // the page down on its own past the hero image until the
                        // Chapters section comes into view, then hand control
                        // back to the person so they can scroll up and down
                        // normally by hand. Phones/tablets and portrait screens
                        // are untouched. Mirrors the same auto-scroll behavior
                        // already used on the Year 2 subjects page.
                        var pmicLandscapeMql = window.matchMedia('(orientation: landscape)');
                        function pmicAutoScrollToChapters() {
                            if (!pmicLandscapeMql.matches) return;
                            setTimeout(function () {
                                chaptersSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }, 60);
                        }

                        // Re-run the auto-scroll any time the screen switches
                        // INTO desktop-landscape while this page is already
                        // open — e.g. rotating a tablet back and forth, or
                        // resizing a browser window — not just when the page
                        // first opens.
                        function pmicHandleOrientationSwitch() {
                            if (!page.classList.contains('active')) return;
                            pmicAutoScrollToChapters();
                        }
                        if (pmicLandscapeMql.addEventListener) {
                            pmicLandscapeMql.addEventListener('change', pmicHandleOrientationSwitch);
                        } else if (pmicLandscapeMql.addListener) {
                            // Older Safari only supports this legacy form.
                            pmicLandscapeMql.addListener(pmicHandleOrientationSwitch);
                        }
                        // Belt-and-braces: some browsers/devices report
                        // orientation changes more reliably through this event
                        // than through the matchMedia listener above.
                        window.addEventListener('orientationchange', function () {
                            setTimeout(pmicHandleOrientationSwitch, 150);
                        });

                        window.pmicGoTo = function (which) {
                            if (which === 'chapters') {
                                chaptersSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            } else {
                                scrollEl.scrollTo({ top: 0, behavior: 'smooth' });
                                setTimeout(updateStuck, 350);
                            }
                        };

                        var scrollTicking = false;
                        scrollEl.addEventListener('scroll', function () {
                            if (scrollTicking) return;
                            scrollTicking = true;
                            requestAnimationFrame(function () {
                                updateStuck();
                                setActive(chaptersIsActive() ? 'chapters' : 'overview');
                                scrollTicking = false;
                            });
                        }, { passive: true });

                        window.addEventListener('resize', function () {
                            syncHeroHeight();
                            updateStuck();
                            pmicSyncTabbarPosition();
                        }, { passive: true });
                        window.addEventListener('orientationchange', function () {
                            setTimeout(function () {
                                syncHeroHeight();
                                updateStuck();
                                pmicSyncTabbarPosition();
                            }, 150);
                        });

                        var wasPageActive = page.classList.contains('active');
                        var mo = new MutationObserver(function () {
                            var isActiveNow = page.classList.contains('active');
                            // Only react when the page just BECAME active — not on
                            // every class mutation (updateStuck() itself toggles a
                            // class on this same element, which would otherwise
                            // re-trigger this observer and loop forever).
                            if (isActiveNow && !wasPageActive) {
                                // Reopening this subject page (e.g. via back from a
                                // unit, or navigating to it again) should always
                                // start fresh at the top with the Overview tab —
                                // not resume wherever the previous visit left off.
                                scrollEl.scrollTop = 0;
                                isStuck = false;
                                tabbar.classList.remove('is-stuck');
                                page.classList.remove('pmic-stuck');
                                setActive('overview');
                                setTimeout(function () {
                                    syncHeroHeight();
                                    updateStuck();
                                    pmicSyncTabbarPosition();
                                    setActive(chaptersIsActive() ? 'chapters' : 'overview');
                                    pmicAutoScrollToChapters();
                                }, 50);
                            }
                            wasPageActive = isActiveNow;
                        });
                        mo.observe(page, { attributes: true, attributeFilter: ['class'] });

                        updateStuck();
                        if (wasPageActive) {
                            // Page was already open when this script ran (e.g.
                            // it's the very first page shown on load) — still
                            // auto-scroll.
                            pmicAutoScrollToChapters();
                        }
                    }
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', pmicInit);
                    } else {
                        pmicInit();
                    }
                })();
            
