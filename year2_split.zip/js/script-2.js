                (function () {
                    function yr2Init() {
                        var page = document.getElementById('lnYear2');
                        var viewport = document.getElementById('yr2Viewport');
                        var panelChapters = document.getElementById('yr2PanelChapters');
                        var panelOverview = document.getElementById('yr2PanelOverview');
                        var tabOverview = document.getElementById('yr2TabOverview');
                        var tabChapters = document.getElementById('yr2TabChapters');
                        if (!page || !viewport || !panelChapters || !panelOverview || !tabOverview || !tabChapters) return;
                        if (page._yr2InitDone) return;
                        page._yr2InitDone = true;

                        var current = 'chapters';

                        function setActive(which) {
                            current = which;
                            if (which === 'chapters') {
                                tabChapters.classList.add('active');
                                tabOverview.classList.remove('active');
                                panelChapters.classList.add('active');
                                panelOverview.classList.remove('active');
                            } else {
                                tabOverview.classList.add('active');
                                tabChapters.classList.remove('active');
                                panelOverview.classList.add('active');
                                panelChapters.classList.remove('active');
                            }
                        }

                        window.yr2GoTo = function (which) {
                            setActive(which);
                        };

                        // Swipe support: swipe left -> Overview, swipe right -> Subjects.
                        var touchStartX = null, touchStartY = null, touchDragging = false;
                        viewport.addEventListener('touchstart', function (e) {
                            var t = e.touches[0];
                            touchStartX = t.clientX;
                            touchStartY = t.clientY;
                            touchDragging = true;
                        }, { passive: true });
                        viewport.addEventListener('touchend', function (e) {
                            if (!touchDragging || touchStartX === null) return;
                            touchDragging = false;
                            var t = e.changedTouches[0];
                            var dx = t.clientX - touchStartX;
                            var dy = t.clientY - touchStartY;
                            if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.5) {
                                if (dx < 0 && current === 'chapters') setActive('overview');
                                else if (dx > 0 && current === 'overview') setActive('chapters');
                            }
                            touchStartX = null;
                            touchStartY = null;
                        }, { passive: true });

                        // Desktop + landscape only: when this page opens, glide the
                        // page down on its own until the Subjects list comes into
                        // view (past the hero image), then hand control back to the
                        // person so they can scroll up and down normally by hand.
                        // Phones/tablets and portrait screens are untouched.
                        var yr2Body = document.getElementById('yr2Body');
                        function yr2AutoScrollToSubjects() {
                            if (!yr2Body) return;
                            var isDesktopLandscape = window.matchMedia(
                                '(orientation: landscape)'
                            ).matches;
                            if (!isDesktopLandscape) return;
                            // Small delay lets the page finish showing/laying out
                            // first, so the scroll distance is measured correctly.
                            setTimeout(function () {
                                yr2Body.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }, 60);
                        }

                        var wasPageActive = page.classList.contains('active');
                        var mo = new MutationObserver(function () {
                            var isActiveNow = page.classList.contains('active');
                            if (isActiveNow && !wasPageActive) {
                                // Reopening this page (e.g. via back from a subject,
                                // or navigating to it again) should always start
                                // fresh on the Subjects panel.
                                setActive('chapters');
                                yr2AutoScrollToSubjects();
                            }
                            wasPageActive = isActiveNow;
                        });
                        mo.observe(page, { attributes: true, attributeFilter: ['class'] });

                        // Also re-run the auto-scroll any time the screen switches
                        // INTO desktop-landscape while this page is already open —
                        // e.g. rotating a tablet back and forth, or resizing a
                        // browser window — not just the one time the page opens.
                        var yr2LandscapeMql = window.matchMedia(
                            '(orientation: landscape)'
                        );
                        function yr2HandleOrientationSwitch() {
                            if (!page.classList.contains('active')) return;
                            if (!yr2LandscapeMql.matches) return;
                            yr2AutoScrollToSubjects();
                        }
                        if (yr2LandscapeMql.addEventListener) {
                            yr2LandscapeMql.addEventListener('change', yr2HandleOrientationSwitch);
                        } else if (yr2LandscapeMql.addListener) {
                            // Older Safari only supports this legacy form.
                            yr2LandscapeMql.addListener(yr2HandleOrientationSwitch);
                        }
                        // Belt-and-braces: some browsers/devices report
                        // orientation changes more reliably through this event
                        // than through the matchMedia listener above.
                        window.addEventListener('orientationchange', function () {
                            setTimeout(yr2HandleOrientationSwitch, 150);
                        });

                        setActive('chapters');
                        if (wasPageActive) {
                            // Page was already open when this script ran (e.g. it's
                            // the very first page shown on load) — still auto-scroll.
                            yr2AutoScrollToSubjects();
                        }
                    }
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', yr2Init);
                    } else {
                        yr2Init();
                    }
                })();
            
